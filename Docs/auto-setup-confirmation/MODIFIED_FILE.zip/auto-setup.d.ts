import type { AgentProfile, AgentOrchestrationStrategy, PendingAutoSetupDraft, WorkflowDefinition } from '../types.js';
export type AutoSetupIntent = {
    kind: 'none';
} | {
    kind: 'confirm';
} | {
    kind: 'cancel';
} | {
    kind: 'clarify';
    question: string;
} | {
    kind: 'draft';
    brief: string;
    reason: string;
};
export declare function createMasterSubagentStrategy(members: AgentProfile[]): AgentOrchestrationStrategy;
export declare function classifyAutoSetupIntent(content: string, hasPendingDraft: boolean): AutoSetupIntent;
export declare function buildAutoSetupDraft(brief: string, baseMembers: AgentProfile[]): PendingAutoSetupDraft;
export declare function formatAutoSetupDraft(draft: PendingAutoSetupDraft): string;
export declare function formatAutoSetupApplied(workflow: WorkflowDefinition, strategy: AgentOrchestrationStrategy): string;
