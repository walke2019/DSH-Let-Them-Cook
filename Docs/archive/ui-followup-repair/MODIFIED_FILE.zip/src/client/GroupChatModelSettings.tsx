import React,{useEffect,useId,useMemo,useRef,useState} from 'react'
import type {AgentProfile} from './group-chat-view-types.js'
type Model={provider:string;model:string}
type CatalogModel={provider:string;model:string;name:string;groupName:string}
type Policy=NonNullable<AgentProfile['resiliencePolicy']>
type Catalog={groups:{id:string;name:string;models:{id:string;name:string}[];error?:string}[];recent:Model[];current?:Model}
function labelFor(model:Model){return model.provider&&model.model?`${model.provider} / ${model.model}`:'跟随宿主默认'}
function SearchableModelPicker({label,value,catalog,allowDefault=false,onChange}:{label:string;value:Model;catalog:Catalog;allowDefault?:boolean;onChange:(m:Model)=>void}){
  const [open,setOpen]=useState(false),[query,setQuery]=useState('')
  const root=useRef<HTMLDivElement>(null),search=useRef<HTMLInputElement>(null)
  const id=useId()
  const all:CatalogModel[]=useMemo(()=>catalog.groups.flatMap(g=>g.models.map(m=>({provider:g.id,model:m.id,name:m.name,groupName:g.name}))),[catalog])
  const filtered=all.filter(item=>`${item.provider} ${item.model} ${item.name} ${item.groupName}`.toLowerCase().includes(query.trim().toLowerCase())).slice(0,80)
  useEffect(()=>{if(!open)return;search.current?.focus();const close=(e:PointerEvent)=>{if(e.target instanceof Node&&!root.current?.contains(e.target))setOpen(false)};document.addEventListener('pointerdown',close);return()=>document.removeEventListener('pointerdown',close)},[open])
  const choose=(m:Model)=>{onChange(m);setOpen(false);setQuery('')}
  return <div className="gc-model-picker" ref={root}>
    <span className="gc-model-label">{label}</span>
    <button type="button" className="gc-model-trigger" aria-haspopup="listbox" aria-expanded={open} aria-controls={open?id:undefined} onClick={()=>setOpen(v=>!v)}>
      <span className="gc-model-trigger-text">{labelFor(value)}</span><span className="gc-model-chevron" aria-hidden="true">⌄</span>
    </button>
    {open&&<div className="gc-model-popover" role="dialog" aria-label={`${label}模型选择`} onKeyDown={e=>{if(e.key==='Escape'){e.preventDefault();setOpen(false)} if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();const items=Array.from(e.currentTarget.querySelectorAll<HTMLButtonElement>('.gc-model-option'));const current=items.indexOf(document.activeElement as HTMLButtonElement);const next=current<0?(e.key==='ArrowDown'?0:items.length-1):(current+(e.key==='ArrowDown'?1:-1)+items.length)%items.length;items[next]?.focus()} if(e.key==='Enter'&&e.target===search.current&&filtered[0]){e.preventDefault();choose(filtered[0])}}}>
      <input ref={search} className="gc-model-search" aria-label={`搜索${label}模型`} placeholder="搜索 Provider / 模型 ID / 名称…" value={query} onChange={e=>setQuery(e.target.value)}/>
      <div className="gc-model-list" id={id} role="listbox">
        {allowDefault&&<button type="button" className="gc-model-option" role="option" onClick={()=>choose({provider:'',model:''})}><span>跟随宿主默认</span><small>{catalog.current?.model?labelFor(catalog.current):'使用当前宿主会话模型'}</small></button>}
        {catalog.recent.filter(m=>m.provider&&m.model).map((m,i)=><button type="button" className="gc-model-option gc-model-recent" role="option" key={`recent-${i}`} onClick={()=>choose(m)}><span>{labelFor(m)}</span><small>最近使用</small></button>)}
        {filtered.map(item=><button type="button" className="gc-model-option" role="option" key={`${item.provider}/${item.model}`} onClick={()=>choose({provider:item.provider,model:item.model})}><span>{item.provider} / {item.model}</span><small>{item.groupName} · {item.name}</small></button>)}
        {!filtered.length&&!catalog.recent.length&&<div className="gc-model-empty">没有匹配结果，可在下方手动输入完整 ID。</div>}
      </div>
    </div>}
  </div>
}
export function GroupChatModelSettings({role,primary,policy,onPrimary,onPolicy}:{role:AgentProfile;primary:Model;policy:Policy;onPrimary:(m:Model)=>void;onPolicy:(p:Policy)=>void}){
  const [catalog,setCatalog]=useState<Catalog>({groups:[],recent:[]})
  const [status,setStatus]=useState('正在加载宿主模型目录…')
  const [reload,setReload]=useState(0)
  useEffect(()=>{const abort=new AbortController();fetch('/dsh-group-chat/api/models',{signal:abort.signal}).then(async r=>{if(!r.ok)throw Error('目录加载失败');return r.json()}).then(data=>{setCatalog(data);setStatus(data.groups.some((g:Catalog['groups'][number])=>g.error)?'部分目录加载失败；仍可手动填写模型 ID。':'')}).catch(e=>{if(!abort.signal.aborted)setStatus(e.message+'，可手动输入或重试。')});return()=>abort.abort()},[reload])
  const models=catalog.groups.flatMap(g=>g.models.map(m=>({provider:g.id,model:m.id,name:m.name,groupName:g.name})))
  const pattern=({backend:/code|coder|codex/i,frontend:/code|coder|codex/i,qa:/reason|thinking|r1|code/i,commander:/reason|thinking|r1/i,researcher:/reason|thinking|pro|search/i,writer:/chat|instruct|flash/i} as Record<string,RegExp>)[role.id]||/chat|instruct/i
  const suggestions=models.filter(m=>pattern.test(m.model+' '+m.name)).slice(0,4)
  const manualRow=(label:string,value:Model,change:(m:Model)=>void)=><div className="gc-model-row"><label>{label} Provider<input aria-label={`${label} Provider 手动输入`} placeholder="Provider" value={value.provider} onChange={e=>change({...value,provider:e.target.value})}/></label><label>模型 ID<input aria-label={`${label}模型 ID 手动输入`} placeholder="模型 ID" value={value.model} onChange={e=>change({...value,model:e.target.value})}/></label></div>
  return <section className="gc-model-settings" aria-label="角色模型与回退设置">
    <style>{`.gc-model-settings{border-top:1px solid var(--dsw-alias-border-l2,#ffffff1f);padding-top:12px;font-size:12px}.gc-model-settings h3{font-size:13px;margin:0 0 8px}.gc-model-settings p{color:var(--dsw-alias-label-secondary,#aaa);font-size:11px;line-height:1.6}.gc-model-row{display:grid;grid-template-columns:minmax(100px,1fr) minmax(140px,2fr);gap:8px}.gc-model-settings label{display:block;min-width:0}.gc-model-settings input,.gc-model-settings select{display:block;box-sizing:border-box;width:100%;margin:4px 0 8px;padding:7px 9px;border:1px solid var(--dsw-alias-border-l2,#ffffff2b);border-radius:8px;background:var(--dsw-alias-bg-base,#151519);color:inherit;font:inherit}.gc-model-settings input:focus-visible,.gc-model-trigger:focus-visible,.gc-model-search:focus-visible,.gc-model-settings button:focus-visible{outline:2px solid var(--dsw-alias-state-business-primary,#4d6bfe);outline-offset:2px}.gc-model-settings button{padding:5px 9px;margin:2px;border:1px solid var(--dsw-alias-border-l2,#ffffff26);border-radius:8px;background:var(--dsw-alias-bg-layer-1,#202025);color:inherit;font:inherit;cursor:pointer}.gc-model-settings button:hover{background:var(--dsw-alias-bg-layer-2,#2b2b31)}.gc-model-settings button:disabled{opacity:.4;cursor:default}.gc-fallback-item{padding:9px;margin-top:8px;border:1px solid var(--dsw-alias-border-l1,#ffffff17);border-radius:10px;background:color-mix(in oklab,var(--dsw-alias-bg-layer-2,#1b1b1f) 72%,transparent)}.gc-model-numbers{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.gc-model-picker{position:relative;margin:7px 0}.gc-model-label{display:block;color:var(--dsw-alias-label-secondary,#cbd5e1);font-size:11px;margin-bottom:5px}.gc-model-trigger{display:flex!important;align-items:center;justify-content:space-between;gap:8px;width:100%;min-height:34px;text-align:left}.gc-model-trigger-text{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.gc-model-chevron{width:16px;height:16px;display:grid;place-items:center;opacity:.75}.gc-model-popover{position:absolute;z-index:10002;left:0;right:0;top:calc(100% + 6px);padding:8px;border:1px solid var(--dsw-alias-border-l2,#ffffff2b);border-radius:14px;background:var(--dsw-alias-bg-layer-1,#202025);box-shadow:0 18px 48px #0008}.gc-model-search{margin:0 0 7px!important}.gc-model-list{max-height:260px;overflow:auto;display:flex;flex-direction:column;gap:2px}.gc-model-option{display:flex!important;flex-direction:column;align-items:flex-start;width:100%;text-align:left;margin:0!important;background:transparent!important;border:0!important}.gc-model-option span{font-size:12px}.gc-model-option small{font-size:10px;color:var(--dsw-alias-label-tertiary,#9696a3);max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.gc-model-recent span:before{content:'最近 · ';color:var(--dsw-alias-state-business-primary,#4d6bfe)}.gc-model-empty{padding:12px;color:var(--dsw-alias-label-tertiary,#999);font-size:11px}`}</style>
    <h3>主模型</h3>
    <SearchableModelPicker label="主模型" value={primary} catalog={catalog} allowDefault onChange={onPrimary}/>
    {manualRow('主模型',primary,onPrimary)}
    <p>下拉数据来自插件服务端调用 DSH 官方模型目录 ctx.llm.listProviders/listModels；两项留空时跟随宿主{catalog.current?.model?`：${catalog.current.provider} / ${catalog.current.model}`:'默认模型'}。</p>
    {status&&<p role="status">{status} <button type="button" onClick={()=>setReload(v=>v+1)}>刷新目录</button></p>}
    <p>角色建议：按模型名称匹配「{role.title||role.id}」职责，仅供选择参考。</p>
    {suggestions.length?suggestions.map(m=><button type="button" key={m.provider+'/'+m.model} onClick={()=>onPrimary({provider:m.provider,model:m.model})}>{m.provider} / {m.model}</button>):<p>当前目录没有明确匹配项。</p>}
    <h3 style={{marginTop:14}}>回退模型 · 按顺序尝试</h3>
    <p>主模型失败并耗尽重试后，依次切换下列模型。</p>
    {policy.fallbackModels.map((m,i)=><div className="gc-fallback-item" key={i}>
      <SearchableModelPicker label={`回退 ${i+1}`} value={m} catalog={catalog} onChange={value=>onPolicy({...policy,fallbackModels:policy.fallbackModels.map((old,j)=>j===i?value:old)})}/>
      {manualRow(`回退 ${i+1}`,m,value=>onPolicy({...policy,fallbackModels:policy.fallbackModels.map((old,j)=>j===i?value:old)}))}
      <button type="button" disabled={i===0} onClick={()=>{const next=[...policy.fallbackModels];[next[i-1],next[i]]=[next[i],next[i-1]];onPolicy({...policy,fallbackModels:next})}}>上移</button>
      <button type="button" onClick={()=>onPolicy({...policy,fallbackModels:policy.fallbackModels.filter((_,j)=>j!==i)})}>移除回退 {i+1}</button>
    </div>)}
    <button type="button" disabled={policy.fallbackModels.length>=5} onClick={()=>onPolicy({...policy,fallbackModels:[...policy.fallbackModels,{provider:'',model:''}]})}>＋ 添加回退模型</button>
    <div className="gc-model-numbers"><label>每模型重试次数<input aria-label="每模型重试次数" type="number" min={0} max={5} value={policy.maxRetriesPerModel} onChange={e=>onPolicy({...policy,maxRetriesPerModel:Number(e.target.value)})}/></label><label>退避毫秒<input aria-label="退避毫秒" type="number" min={0} max={60000} value={policy.retryBackoffMs} onChange={e=>onPolicy({...policy,retryBackoffMs:Number(e.target.value)})}/></label><label>超时毫秒<input aria-label="超时毫秒" type="number" min={1000} max={600000} value={policy.timeoutMs} onChange={e=>onPolicy({...policy,timeoutMs:Number(e.target.value)})}/></label></div>
  </section>
}
