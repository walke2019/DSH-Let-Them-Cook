/**
 * DSH Group Chat - 房间状态机、成员花名册、事件分发与消息持久化 (Room Coordinator)
 */
import type { GroupChatRoom, GroupMessageEnvelope, AgentProfile, RoomLedger, GroupChatEvent, DispatchMode, PersonaThemeKey } from '../types.js';
export declare class RoomManager {
    private rooms;
    private roomMessages;
    private roomMessageLists;
    private roomLedgers;
    private eventListeners;
    constructor();
    /**
     * 构建基础 6 大核心角色清单
     */
    createDefaultFleet(theme?: PersonaThemeKey): AgentProfile[];
    /**
     * 初始化内置业务模板房间
     */
    private initDefaultRooms;
    private initLedger;
    getRoom(roomId: string): GroupChatRoom | undefined;
    getAllRooms(): GroupChatRoom[];
    getMessages(roomId: string): GroupMessageEnvelope[];
    getLedger(roomId: string): RoomLedger | undefined;
    /**
     * 切换房间名号映射主题 (modern / three_kingdoms / legends)
     */
    switchTheme(roomId: string, theme: PersonaThemeKey): GroupChatRoom | undefined;
    /**
     * 自定义更新指定角色档案 (修改姓名、头像/本地上传图片、职责、提示词、模型、权限)
     */
    updateAgentProfile(roomId: string, agentId: string, updates: Partial<Pick<AgentProfile, 'name' | 'avatar' | 'title' | 'roleDescription' | 'systemPrompt' | 'llmConfig' | 'permissions' | 'resiliencePolicy'>>): AgentProfile | undefined;
    /**
     * 注册事件订阅
     */
    subscribe(listener: (event: GroupChatEvent) => void): () => void;
    /**
     * 广播事件
     */
    broadcast(event: GroupChatEvent): void;
    /**
     * 创建或保存房间
     */
    saveRoom(room: GroupChatRoom): void;
    /**
     * 切换调度模式
     */
    setDispatchMode(roomId: string, mode: DispatchMode): GroupChatRoom | undefined;
    /**
     * 更新共享黑板 (需校验写入权限)
     */
    updateScratchpad(roomId: string, scratchpad: string, operatorRoleId?: string): {
        success: boolean;
        message: string;
        room?: GroupChatRoom;
    };
    /**
     * 添加消息并记账
     */
    addMessage(roomId: string, message: Omit<GroupMessageEnvelope, 'messageId' | 'timestamp'> & {
        messageId?: string;
    }): GroupMessageEnvelope;
    /**
     * 重置单次人类指令的互动轮数计数
     */
    resetInteractionRound(roomId: string): void;
    /**
     * 递增单次交互轮数
     */
    incrementInteractionRound(roomId: string): number;
    /**
     * 导出群聊讨论纪要
     */
    exportMeetingSummary(roomId: string): string;
}
