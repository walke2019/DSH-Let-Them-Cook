import z from '@deepseek-ai/schemastery';
import { type RuntimeContext } from './engine/agent-runtime.js';
export declare const name = "@dsh-external/dsh-group-chat";
export declare const inject: string[];
export interface Config {
    defaultMode: string;
    maxTurnsPerPrompt: number;
    silenceToken: string;
}
export declare const Config: z<Schemastery.ObjectS<{
    defaultMode: z<string, string>;
    maxTurnsPerPrompt: z<number, number>;
    silenceToken: z<string, string>;
}>, Schemastery.ObjectT<{
    defaultMode: z<string, string>;
    maxTurnsPerPrompt: z<number, number>;
    silenceToken: z<string, string>;
}>>;
export type AppContext = RuntimeContext & {
    llm: {
        listProviders(): {
            id: string;
            name: string;
        }[];
        listModels(provider: string): Promise<{
            id: string;
            name: string;
        }[]>;
    };
    webServer: any;
    tools: any;
    logger: any;
};
export declare function apply(ctx: AppContext, config: Config): void;
