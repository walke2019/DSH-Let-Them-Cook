import type { AgentProfile, RoleThemeMapping } from '../types.js';
export declare function buildHumanSystemPrompt(baseRole: AgentProfile, mapping: RoleThemeMapping, worldBrief: string): string;
export declare function createThemeDraft(worldBrief: string, members: AgentProfile[]): {
    name: string;
    avatar: string;
    color: string;
    title: string;
    systemPrompt: string;
    groupChatRules: {
        mentionKeywords: string[];
        canDelegateToOthers: boolean;
        allowedTools?: string[];
    };
    id: string;
    roleDescription: string;
    llmConfig: import("../types.js").ModelRef;
    permissions: import("../types.js").RolePermissions;
    resiliencePolicy?: import("../types.js").ResiliencePolicy;
}[];
