export const ORCHESTRATOR_RUNTIME_SKILL_NAME = 'dsh-group-chat-orchestrator'

export const ORCHESTRATOR_RUNTIME_SKILL_SUMMARY = `【Runtime Skill: dsh-group-chat-orchestrator】
本 Skill 由 dsh-group-chat 扩展在 DSH 运行时注入给群聊 Agent 使用，不是 Codex 开发助手技能。
定位：高自由度多 Agent 项目协同；用户用中间对话描述任务，主 Agent 组织 SubAgent 自主推进。
核心：commander 是主 Agent，负责理解、追问、拆解、派发、审核、收口；其他 Agent 是 SubAgent，按职责执行并回报。
并发：保留 DSH workflow 阶段内多 Agent 并发；同阶段多个 assignedRoleIds 可并发处理不同职责。
工具：搜索/爬取/资料抽取归 researcher；后端/API/状态机归 backend；前端/UI/浏览器调试归 frontend；测试/红队归 qa；文档/摘要归 writer；最终归纳归 commander。
限制：禁止多个 Agent 对同一搜索、爬取、修改、测试任务重复并发调用。
配置：自动角色/工作流创建只先展示待确认草案；用户确认后才写入工作区。
模型：按能力标签推荐，不硬编码唯一模型 ID；用户手动模型设置优先。`
