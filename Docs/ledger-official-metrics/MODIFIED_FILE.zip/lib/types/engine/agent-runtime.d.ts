import type { Context } from '@deepseek-ai/cordis';
import type { AgentRegistry } from '@deepseek-ai/dsh-agent';
import type { AgentRuntimeMetrics, ModelRef } from '../types.js';
export type RuntimeContext = Context & {
    agents: AgentRegistry;
    tools: any;
    systemPrompt: any;
    agentDefaultModel: any;
};
/** One isolated, tool-less group-chat turn, driven by the host agent registry. */
export declare function runMemberTurn(ctx: RuntimeContext, model: ModelRef, prompt: string, signal: AbortSignal): Promise<{
    content: string;
    reasoningContent: string;
    providerUsed: any;
    modelUsed: any;
    metrics: AgentRuntimeMetrics;
}>;
