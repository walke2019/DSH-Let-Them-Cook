import type { GroupChatRoom } from '../types.js';
/** Workspace-owned room state. Stored under the current DSH workspace, never in global host config. */
export declare class WorkspaceRoomStateStore {
    private path;
    private data;
    constructor(path: string);
    get(roomId: string): GroupChatRoom | undefined;
    all(): GroupChatRoom[];
    saveRoom(room: GroupChatRoom): void;
    location(): string;
}
