window.__ModuleLoader__.load({
	id: "@dsh-external/dsh-group-chat",
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
		//#region \0rolldown/runtime.js
		var __create = Object.create;
		var __defProp = Object.defineProperty;
		var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
		var __getOwnPropNames = Object.getOwnPropertyNames;
		var __getProtoOf = Object.getPrototypeOf;
		var __hasOwnProp = Object.prototype.hasOwnProperty;
		var __copyProps = (to, from, except, desc) => {
			if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
				key = keys[i];
				if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
					get: ((k) => from[k]).bind(null, key),
					enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
				});
			}
			return to;
		};
		var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule || !__hasOwnProp.call(mod, "default") ? __defProp(target, "default", {
			value: mod,
			enumerable: true
		}) : target, mod));
		//#endregion
		let react = require("react");
		react = __toESM(react, 1);
		let react_jsx_runtime = require("react/jsx-runtime");
		let _deepseek_ai_dsh_client_ui_primitives = require("@deepseek-ai/dsh-client-ui-primitives");
		//#region src/client/group-chat-events.ts
		/** One plugin SSE connection per client, shared by the dock and conversation. */
		let source = null;
		const listeners = /* @__PURE__ */ new Set();
		function subscribeGroupChat(listener) {
			listeners.add(listener);
			if (!source) {
				source = new EventSource("/dsh-group-chat/api/events");
				source.onmessage = (event) => {
					for (const callback of listeners) callback(event);
				};
			}
			return () => {
				listeners.delete(listener);
				if (!listeners.size) {
					source?.close();
					source = null;
				}
			};
		}
		function disposeGroupChatEvents() {
			source?.close();
			source = null;
			listeners.clear();
		}
		//#endregion
		//#region src/client/AvatarBadge.tsx
		function FeatherSvg({ className, style }) {
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
				className,
				style,
				"aria-hidden": "true",
				"data-avatar-svg": "feather-fan",
				children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("svg", {
					viewBox: "0 0 24 24",
					width: "1em",
					height: "1em",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "1.8",
					strokeLinecap: "round",
					strokeLinejoin: "round",
					style: { display: "block" },
					children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M5 19c4.8-1.2 9-4 12.5-8.5 1.4-1.8 1.8-3.5 1-4.3-.8-.8-2.5-.4-4.3 1C9.8 10.7 7 14.9 5.8 19.6" }),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M8.2 16.8 4 21" }),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M10.1 14.2h4.6" }),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M12.2 11.8h4.2" }),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M14.3 9.3h3.2" })
					]
				})
			});
		}
		function AvatarBadge({ avatar, alt = "", className, style }) {
			const value = avatar || "◉";
			if (/^(data:|https?:)/.test(value)) return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("img", {
				className,
				style,
				src: value,
				alt
			});
			if (value === "🪶" || value === ":feather:" || value === "feather") return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(FeatherSvg, {
				className,
				style
			});
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
				className,
				style,
				"aria-hidden": "true",
				children: value
			});
		}
		//#endregion
		//#region src/client/GroupChatComposer.tsx
		/** Compact group composer; the member roster stays inside a searchable picker. */
		function GroupChatComposer({ members, value, onChange, onSend, sending }) {
			const [open, setOpen] = (0, react.useState)(false);
			const [query, setQuery] = (0, react.useState)("");
			const root = (0, react.useRef)(null);
			const textarea = (0, react.useRef)(null);
			const trigger = (0, react.useRef)(null);
			const search = (0, react.useRef)(null);
			const selection = (0, react.useRef)({
				start: value.length,
				end: value.length
			});
			const id = (0, react.useId)();
			const options = [...members, {
				id: "all",
				name: "全员争鸣",
				avatar: "◎",
				title: "邀请所有角色参与"
			}].filter((m) => `${m.name} ${m.id} ${m.title ?? ""}`.toLowerCase().includes(query.toLowerCase().trim()));
			(0, react.useLayoutEffect)(() => {
				const el = textarea.current;
				if (!el) return;
				el.style.height = "auto";
				el.style.height = `${Math.min(160, Math.max(76, el.scrollHeight))}px`;
			}, [value]);
			(0, react.useEffect)(() => {
				if (!open) return;
				search.current?.focus();
				const dismiss = (e) => {
					if (e.target instanceof Node && !root.current?.contains(e.target)) setOpen(false);
				};
				document.addEventListener("pointerdown", dismiss);
				return () => document.removeEventListener("pointerdown", dismiss);
			}, [open]);
			const choose = (member) => {
				const start = Math.min(selection.current.start, value.length);
				const end = Math.min(selection.current.end, value.length);
				const before = value.slice(0, start);
				const mention = `${before && !/\s$/.test(before) ? " " : ""}@${member.name} `;
				onChange(before + mention + value.slice(end));
				setOpen(false);
				requestAnimationFrame(() => {
					textarea.current?.focus();
					textarea.current?.setSelectionRange(start + mention.length, start + mention.length);
				});
			};
			const close = () => {
				setOpen(false);
				trigger.current?.focus();
			};
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: "gc-composer",
				ref: root,
				onBlur: (e) => {
					if (e.relatedTarget instanceof Node && !e.currentTarget.contains(e.relatedTarget)) setOpen(false);
				},
				children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("style", { children: `
      .gc-composer { flex-shrink:0; padding:12px 20px 16px; color:var(--dsw-alias-label-primary,#f8fafc); }
      .gc-composer-card { position:relative; max-width:960px; margin:0 auto; padding:12px; border:1px solid var(--dsw-alias-border-l2,#34343a); border-radius:22px; background:var(--dsw-alias-bg-layer-1,#18181c); box-shadow:0 2px 10px #00000010; }
      .gc-composer-card:focus-within { border-color:var(--dsw-alias-label-tertiary,#757580); }
      .gc-composer textarea { display:block; box-sizing:border-box; width:100%; min-height:76px; max-height:160px; resize:none; border:0; padding:3px 5px 8px; outline:none; background:transparent; color:inherit; font-size:14px; font-family:inherit; line-height:1.6; overflow-y:auto; }
      .gc-composer textarea::placeholder { color:var(--dsw-alias-label-tertiary,#9696a3); }
      .gc-composer-tools { display:flex; align-items:center; justify-content:space-between; gap:8px; }
      .gc-mention-trigger { display:flex; align-items:center; gap:6px; padding:6px 9px; border:0; border-radius:9px; background:transparent; color:var(--dsw-alias-label-secondary,#cbd5e1); font:inherit; font-size:12px; cursor:pointer; }
      .gc-mention-chevron{width:14px;height:14px;display:block;transition:transform .15s ease;opacity:.8;}
      .gc-mention-trigger[aria-expanded=true] .gc-mention-chevron{transform:rotate(180deg);}
      .gc-mention-trigger:hover,.gc-mention-trigger[aria-expanded=true] { background:var(--dsw-alias-bg-layer-2,#303036); }
      .gc-composer button:focus-visible,.gc-member-search:focus-visible { outline:2px solid #7b91ff; outline-offset:2px; }
      .gc-send { display:grid; place-items:center; flex-shrink:0; width:32px; height:32px; border:0; border-radius:50%; color:#fff; background:#4d6bfe; cursor:pointer; }
      .gc-send:disabled { background:var(--dsw-alias-bg-layer-2,#303036); color:#777782; cursor:default; }
      .gc-composer-help { color:var(--dsw-alias-label-tertiary,#9999a5); font-size:11px; margin-left:auto; }
      .gc-member-picker { position:absolute; left:10px; bottom:54px; z-index:30; width:min(300px,calc(100% - 20px)); padding:8px; box-sizing:border-box; border:1px solid var(--dsw-alias-border-l2,#42424b); border-radius:14px; background:var(--dsw-alias-bg-layer-1,#202025); box-shadow:0 8px 28px #0005; }
      .gc-picker-title { font-size:12px; color:var(--dsw-alias-label-secondary,#cbd5e1); padding:3px 4px 8px; }
      .gc-member-search { box-sizing:border-box; width:100%; border:1px solid var(--dsw-alias-border-l2,#42424b); border-radius:8px; padding:8px; color:inherit; background:var(--dsw-alias-bg-base,#151519); font:inherit; font-size:12px; }
      .gc-member-options { max-height:210px; overflow-y:auto; margin-top:6px; }
      .gc-member-option { display:flex; gap:10px; align-items:center; text-align:left; width:100%; border:0; border-radius:8px; padding:8px; color:inherit; background:transparent; cursor:pointer; }
      .gc-member-option:hover,.gc-member-option:focus-visible { background:var(--dsw-alias-bg-layer-2,#303036); }
      .gc-member-option img,.gc-member-avatar { width:26px; height:26px; display:grid; place-items:center; object-fit:cover; border-radius:7px; flex-shrink:0; }
      .gc-member-copy { min-width:0; display:flex; flex-direction:column; gap:2px; }
      .gc-member-copy strong { font-size:12px; font-weight:500; }
      .gc-member-copy small { font-size:11px; color:var(--dsw-alias-label-tertiary,#9999a5); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
      @media(max-width:600px) { .gc-composer{padding:8px;} .gc-composer-help{display:none;} }
    ` }), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					className: "gc-composer-card",
					children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("textarea", {
							ref: textarea,
							"aria-label": "群聊消息",
							placeholder: "发送消息，或选择 @ 角色…",
							value,
							disabled: sending,
							onChange: (e) => onChange(e.target.value),
							onSelect: (e) => {
								selection.current = {
									start: e.currentTarget.selectionStart,
									end: e.currentTarget.selectionEnd
								};
							},
							onKeyDown: (e) => {
								if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing && e.keyCode !== 229) {
									e.preventDefault();
									if (value.trim() && !sending) onSend();
								}
							}
						}),
						open && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							id,
							className: "gc-member-picker",
							role: "dialog",
							"aria-label": "选择角色",
							onKeyDown: (e) => {
								if (e.key === "Escape") {
									e.preventDefault();
									e.stopPropagation();
									close();
								}
								if (e.key === "ArrowDown" || e.key === "ArrowUp") {
									e.preventDefault();
									const items = Array.from(e.currentTarget.querySelectorAll(".gc-member-option"));
									const current = items.indexOf(document.activeElement);
									items[current < 0 ? e.key === "ArrowDown" ? 0 : items.length - 1 : (current + (e.key === "ArrowDown" ? 1 : -1) + items.length) % items.length]?.focus();
								}
								if (e.key === "Enter" && e.target === search.current && options.length) {
									e.preventDefault();
									choose(options[0]);
								}
							},
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: "gc-picker-title",
									children: "选择要 @ 的角色"
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
									className: "gc-member-search",
									ref: search,
									"aria-label": "搜索角色",
									placeholder: "搜索角色…",
									value: query,
									onChange: (e) => setQuery(e.target.value)
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: "gc-member-options",
									children: [options.map((m) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
										type: "button",
										className: "gc-member-option",
										onClick: () => choose(m),
										children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(AvatarBadge, {
											avatar: m.avatar,
											className: "gc-member-avatar"
										}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
											className: "gc-member-copy",
											children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: m.name }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("small", { children: m.title || m.id })]
										})]
									}, m.id)), !options.length && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
										role: "status",
										style: {
											padding: 12,
											fontSize: 12
										},
										children: "没有匹配的角色"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: "gc-composer-tools",
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
									type: "button",
									ref: trigger,
									className: "gc-mention-trigger",
									"aria-label": "选择要提及的角色",
									"aria-haspopup": "dialog",
									"aria-expanded": open,
									"aria-controls": open ? id : void 0,
									disabled: sending,
									onClick: () => {
										setQuery("");
										setOpen((v) => !v);
									},
									children: [
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											"aria-hidden": "true",
											style: { fontSize: 17 },
											children: "@"
										}),
										"角色",
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("svg", {
											className: "gc-mention-chevron",
											viewBox: "0 0 16 16",
											fill: "none",
											stroke: "currentColor",
											strokeWidth: "1.8",
											strokeLinecap: "round",
											strokeLinejoin: "round",
											"aria-hidden": "true",
											children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M4 6l4 4 4-4" })
										})
									]
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: "gc-composer-help",
									children: "Enter 发送 · Shift+Enter 换行"
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
									type: "button",
									className: "gc-send",
									"aria-label": sending ? "正在发送" : "发送消息",
									title: "发送消息",
									disabled: sending || !value.trim(),
									onClick: onSend,
									children: sending ? "…" : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("svg", {
										width: "18",
										height: "18",
										viewBox: "0 0 24 24",
										fill: "none",
										stroke: "currentColor",
										strokeWidth: "2",
										"aria-hidden": "true",
										children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M12 19V5m-6 6 6-6 6 6" })
									})
								})
							]
						})
					]
				})]
			});
		}
		//#endregion
		//#region src/client/GroupChatPanel.tsx
		function GroupChatPanel({ mode = "full" }) {
			const [members, setMembers] = (0, react.useState)([]);
			const [messages, setMessages] = (0, react.useState)([]);
			const [draft, setDraft] = (0, react.useState)("");
			const [sending, setSending] = (0, react.useState)(false);
			const [loading, setLoading] = (0, react.useState)(true);
			const [error, setError] = (0, react.useState)("");
			const [copied, setCopied] = (0, react.useState)("");
			const [retry, setRetry] = (0, react.useState)(0);
			const scroll = (0, react.useRef)(null);
			const bottom = (0, react.useRef)(null);
			const follow = (0, react.useRef)(true);
			const [showLatest, setShowLatest] = (0, react.useState)(false);
			const [agentStatuses, setAgentStatuses] = (0, react.useState)({});
			const [statusOpen, setStatusOpen] = (0, react.useState)(() => localStorage.getItem("dsh-group-chat.status-open") !== "false");
			const [statusPos, setStatusPos] = (0, react.useState)(() => {
				try {
					return JSON.parse(localStorage.getItem("dsh-group-chat.status-pos") || "{\"x\":18,\"y\":18}");
				} catch {
					return {
						x: 18,
						y: 18
					};
				}
			});
			const drag = (0, react.useRef)(null);
			const roomId = "dev-team-alpha";
			(0, react.useEffect)(() => {
				if (mode !== "full") return;
				document.body.setAttribute("data-dsh-group-chat-active", "true");
				return () => document.body.removeAttribute("data-dsh-group-chat-active");
			}, [mode]);
			(0, react.useEffect)(() => {
				const controller = new AbortController();
				const upsert = (list) => setMessages((prev) => {
					const byId = new Map(prev.map((m) => [m.messageId, m]));
					for (const message of list) byId.set(message.messageId, message);
					return [...byId.values()].sort((a, b) => a.timestamp - b.timestamp);
				});
				setLoading(true);
				setError("");
				fetch(`/dsh-group-chat/api/room?id=${roomId}`, { signal: controller.signal }).then(async (r) => {
					if (!r.ok) throw Error(`加载失败 (${r.status})`);
					const data = await r.json();
					if (!data.room) throw Error("群聊数据暂未就绪");
					if (controller.signal.aborted) return;
					setMembers(data.room.members);
					upsert(data.messages || []);
				}).catch((e) => {
					if (!controller.signal.aborted) setError(e.message);
				}).finally(() => {
					if (!controller.signal.aborted) setLoading(false);
				});
				const unsubscribe = subscribeGroupChat((e) => {
					if (controller.signal.aborted) return;
					try {
						const event = JSON.parse(e.data);
						if (event.roomId && event.roomId !== roomId) return;
						if (event.type === "message:new") upsert([event.payload]);
						if (event.type === "room:updated" && event.payload.members) setMembers(event.payload.members);
						if (event.type === "agent:status" && event.payload?.agentId) setAgentStatuses((prev) => ({
							...prev,
							[event.payload.agentId]: event.payload
						}));
					} catch {}
				});
				return () => {
					controller.abort();
					unsubscribe();
				};
			}, [retry]);
			(0, react.useEffect)(() => {
				if (follow.current && scroll.current) scroll.current.scrollTop = scroll.current.scrollHeight;
			}, [messages]);
			(0, react.useEffect)(() => {
				const el = scroll.current;
				if (!el) return;
				const syncBottom = () => {
					const height = bottom.current?.getBoundingClientRect().height || 0;
					el.style.setProperty("--gc-bottom-height", `${Math.ceil(height)}px`);
					if (follow.current) el.scrollTop = el.scrollHeight;
				};
				const observer = new ResizeObserver(syncBottom);
				observer.observe(el);
				if (el.firstElementChild) observer.observe(el.firstElementChild);
				if (bottom.current) observer.observe(bottom.current);
				syncBottom();
				return () => observer.disconnect();
			}, []);
			(0, react.useEffect)(() => {
				localStorage.setItem("dsh-group-chat.status-open", String(statusOpen));
			}, [statusOpen]);
			(0, react.useEffect)(() => {
				localStorage.setItem("dsh-group-chat.status-pos", JSON.stringify(statusPos));
			}, [statusPos]);
			const startDrag = (e) => {
				if (e.target.closest("button")) return;
				const rect = e.currentTarget.getBoundingClientRect();
				drag.current = {
					dx: e.clientX - rect.left,
					dy: e.clientY - rect.top
				};
				e.currentTarget.setPointerCapture(e.pointerId);
			};
			const moveDrag = (e) => {
				if (!drag.current) return;
				const parent = e.currentTarget.offsetParent?.getBoundingClientRect() || {
					left: 0,
					top: 0,
					width: window.innerWidth,
					height: window.innerHeight
				};
				const rect = e.currentTarget.getBoundingClientRect();
				const nextX = Math.max(8, Math.min(parent.width - rect.width - 8, e.clientX - parent.left - drag.current.dx));
				const nextY = Math.max(8, Math.min(parent.height - rect.height - 8, e.clientY - parent.top - drag.current.dy));
				setStatusPos({
					x: Math.round(nextX),
					y: Math.round(nextY)
				});
			};
			const stopDrag = () => {
				drag.current = null;
			};
			const send = async () => {
				if (!draft.trim() || sending) return;
				setSending(true);
				setError("");
				follow.current = true;
				try {
					const response = await fetch("/dsh-group-chat/api/message", {
						method: "POST",
						headers: { "Content-Type": "application/json" },
						body: JSON.stringify({
							roomId,
							content: draft.trim()
						})
					});
					const data = await response.json();
					if (!response.ok || !data.success) throw Error(data.error || "消息发送失败");
					setDraft("");
					setMessages((prev) => prev.some((m) => m.messageId === data.message.messageId) ? prev : [...prev, data.message]);
				} catch (e) {
					setError(e instanceof Error ? e.message : String(e));
				} finally {
					setSending(false);
				}
			};
			const copy = async (message) => {
				try {
					await navigator.clipboard.writeText(message.content);
					setCopied(message.messageId);
				} catch {
					setError("复制失败，请选择消息文字复制");
				}
			};
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				"data-dsh-group-chat-panel": true,
				className: "gc-conversation",
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("style", { children: `
      .gc-conversation{position:relative;display:flex;flex-direction:column;flex:1;min-height:0;height:100%;width:100%;overflow:hidden;color:var(--dsw-alias-label-primary,#eee);font-family:inherit;background:transparent;}
      .gc-chat-scroll{flex:1;min-height:0;overflow:auto;overscroll-behavior:contain;scrollbar-gutter:stable;scroll-behavior:auto;overflow-anchor:none;}
      .gc-scroll-content{min-height:100%;display:flex;flex-direction:column;}
      .gc-chat-messages{flex:1;padding:28px 24px calc(var(--gc-bottom-height,150px) + 24px);}
      .gc-chat-bottom{position:relative;z-index:5;background:var(--dsw-alias-bg-base,#101014);padding-top:10px;}
      .gc-latest{display:block;margin:0 auto 4px;padding:5px 12px;border-radius:16px;border:1px solid #8885;background:var(--dsw-alias-bg-layer-1,#222);color:inherit;cursor:pointer;}
      .gc-agent-float{position:absolute;z-index:6;width:210px;max-width:calc(100% - 36px);border:1px solid var(--dsw-alias-border-l2,#ffffff24);border-radius:16px;background:color-mix(in oklab,var(--dsw-alias-bg-layer-1,#202025) 90%,transparent);box-shadow:0 10px 30px #0004;backdrop-filter:blur(12px);padding:10px;color:inherit;font-size:12px;touch-action:none;}
      .gc-agent-float[data-open=false]{width:auto;padding:6px 8px;}
      .gc-agent-head{display:flex;align-items:center;justify-content:space-between;gap:8px;cursor:grab;user-select:none;}
      .gc-agent-drag{font-size:11px;color:var(--dsw-alias-label-tertiary,#999);font-weight:400;margin-left:4px;}
      .gc-agent-toggle{border:0;background:transparent;color:inherit;cursor:pointer;font:inherit;}
      .gc-agent-list{display:flex;flex-direction:column;gap:7px;margin-top:8px;}
      .gc-agent-item{display:grid;grid-template-columns:24px 1fr auto;align-items:center;gap:8px;}
      .gc-agent-dot{width:7px;height:7px;border-radius:50%;background:#64748b;}
      .gc-agent-item[data-status=running] .gc-agent-dot{background:#4d6bfe;box-shadow:0 0 0 4px #4d6bfe22;}
      .gc-agent-item[data-status=complete] .gc-agent-dot{background:#10b981;}
      .gc-agent-item[data-status=error] .gc-agent-dot{background:#f87171;}
      .gc-agent-name{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600;}
      .gc-agent-sub{grid-column:2/4;color:var(--dsw-alias-label-tertiary,#999);font-size:10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
      .gc-agent-idle{color:var(--dsw-alias-label-tertiary,#999);font-size:11px;margin-top:8px;}
      .gc-chat-thread{width:100%;max-width:960px;margin:0 auto;}
      .gc-chat-empty{height:100%;min-height:130px;display:grid;place-content:center;text-align:center;gap:10px;color:var(--dsw-alias-label-tertiary,#999);font-size:13px;}
      .gc-chat-empty strong{font-size:20px;font-weight:500;color:var(--dsw-alias-label-primary,#eee);}
      .gc-message{margin:0 0 30px;overflow-wrap:anywhere;}
      .gc-message-user{display:flex;flex-direction:column;align-items:flex-end;}
      .gc-message-body{font-size:13px;line-height:1.7;min-width:0;}
      .gc-message-user .gc-message-body{max-width:85%;padding:10px 16px;background:var(--dsw-alias-bg-layer-2,#29292e);border-radius:18px;white-space:pre-wrap;}
      .gc-message-meta{display:flex;align-items:center;gap:8px;margin-bottom:10px;font-size:12px;color:var(--dsw-alias-label-secondary,#aaa);}
      .gc-message-avatar{width:22px;height:22px;display:inline-grid;place-items:center;object-fit:cover;border-radius:6px;}
      .gc-message-role{font-weight:500;color:var(--dsw-alias-label-primary,#eee);}
      .gc-message-actions{display:flex;align-items:center;gap:12px;margin-top:8px;color:var(--dsw-alias-label-tertiary,#999);font-size:11px;}
      .gc-copy{padding:3px 5px;display:flex;align-items:center;gap:4px;border:0;background:transparent;color:inherit;border-radius:5px;cursor:pointer;font:inherit;}
      .gc-copy:hover{background:var(--dsw-alias-bg-layer-2,#29292e);color:var(--dsw-alias-label-primary,#eee);}
      .gc-copy:focus-visible{outline:2px solid #8196ff;}
      .gc-message-system{padding:8px 12px;color:var(--dsw-alias-label-secondary,#aaa);font-size:12px;border-left:2px solid var(--dsw-alias-border-l2,#555);}
      .gc-message details{margin:8px 0;color:var(--dsw-alias-label-secondary,#aaa);font-size:13px;}
      .gc-message summary{cursor:pointer;}
      .gc-message pre{max-width:100%;overflow:auto;}
      .gc-message-body>div{min-width:0;font-size:inherit!important;line-height:inherit!important;}
      .gc-message-body :is(p,li,td,th){font-size:13px;line-height:1.7;}
      .gc-message-body pre,.gc-message-body code{font-size:12px;}
      .gc-message-tools pre{white-space:pre-wrap;max-height:240px;}
      .gc-chat-error{margin:8px auto;max-width:960px;padding:8px 16px;font-size:12px;color:#fca5a5;}
      @media(max-width:900px){.gc-agent-float{display:none;}}
      @media(max-width:600px){.gc-chat-messages{padding:16px 12px calc(var(--gc-bottom-height,150px) + 20px);}.gc-message-user .gc-message-body{max-width:94%;}}
    ` }),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: "gc-agent-float",
						"data-open": statusOpen,
						"aria-label": "当前执行 Agent 状态",
						style: {
							left: statusPos.x,
							top: statusPos.y
						},
						onPointerDown: startDrag,
						onPointerMove: moveDrag,
						onPointerUp: stopDrag,
						onPointerCancel: stopDrag,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: "gc-agent-head",
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("strong", { children: ["Agent 状态 ", /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: "gc-agent-drag",
								children: "拖动"
							})] }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								type: "button",
								className: "gc-agent-toggle",
								onClick: () => setStatusOpen((v) => !v),
								children: statusOpen ? "隐藏" : "显示"
							})]
						}), statusOpen && (Object.values(agentStatuses).length ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: "gc-agent-list",
							children: Object.values(agentStatuses).sort((a, b) => (b.startedAt || b.finishedAt || 0) - (a.startedAt || a.finishedAt || 0)).slice(0, 5).map((item) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: "gc-agent-item",
								"data-status": item.status,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(AvatarBadge, { avatar: item.avatar }),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: "gc-agent-name",
										children: item.name
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: "gc-agent-dot",
										title: item.status
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
										className: "gc-agent-sub",
										children: [
											item.status === "running" ? "执行中" : item.status === "complete" ? "已完成" : "出错",
											item.modelUsed ? ` · ${item.providerUsed || ""}/${item.modelUsed}` : "",
											item.message ? ` · ${item.message}` : ""
										]
									})
								]
							}, item.agentId))
						}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: "gc-agent-idle",
							children: "当前没有正在执行的角色。"
						}))]
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						ref: scroll,
						className: "gc-chat-scroll",
						onScroll: (e) => {
							const el = e.currentTarget;
							follow.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
							setShowLatest(!follow.current);
						},
						children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: "gc-scroll-content",
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: "gc-chat-messages",
								children: !messages.length ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: "gc-chat-empty",
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: loading ? "正在加载…" : "开始群聊" }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: loading ? "" : "发送消息，或通过下方 @ 选择角色" })]
								}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: "gc-chat-thread",
									role: "log",
									"aria-label": "群聊消息记录",
									"aria-live": "polite",
									"aria-relevant": "additions",
									children: messages.filter((m) => !m.metadata?.isSilent).map((message) => {
										const user = message.sender.kind === "user";
										if (message.sender.kind === "system") return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
											className: "gc-message gc-message-system",
											children: message.content
										}, message.messageId);
										return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("article", {
											className: `gc-message ${user ? "gc-message-user" : "gc-message-agent"}`,
											"aria-label": `${message.sender.name}的消息`,
											children: [
												!user && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
													className: "gc-message-meta",
													children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(AvatarBadge, {
														avatar: message.sender.avatar,
														className: "gc-message-avatar"
													}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
														className: "gc-message-role",
														children: message.sender.name
													})]
												}),
												message.reasoningContent && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("details", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("summary", { children: "思考过程" }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.MarkdownText, { text: message.reasoningContent })] }),
												message.metadata?.toolCalls?.map((tool) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("details", {
													className: "gc-message-tools",
													children: [
														/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("summary", { children: [
															tool.name,
															" · ",
															tool.status
														] }),
														/* @__PURE__ */ (0, react_jsx_runtime.jsx)("pre", { children: tool.arguments }),
														tool.result && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("pre", { children: tool.result })
													]
												}, tool.id)),
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
													className: "gc-message-body",
													children: user ? message.content : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.MarkdownText, { text: message.content })
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
													className: "gc-message-actions",
													children: [
														/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
															type: "button",
															className: "gc-copy",
															onClick: () => copy(message),
															"aria-label": `复制${message.sender.name}的消息`,
															children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("svg", {
																width: "14",
																height: "14",
																viewBox: "0 0 24 24",
																fill: "none",
																stroke: "currentColor",
																strokeWidth: "1.6",
																"aria-hidden": "true",
																children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("rect", {
																	x: "8",
																	y: "8",
																	width: "12",
																	height: "12",
																	rx: "2"
																}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M16 8V4H4v12h4" })]
															}), copied === message.messageId ? "已复制" : "复制"]
														}),
														/* @__PURE__ */ (0, react_jsx_runtime.jsx)("time", {
															dateTime: new Date(message.timestamp).toISOString(),
															children: new Date(message.timestamp).toLocaleTimeString([], {
																hour: "2-digit",
																minute: "2-digit"
															})
														}),
														!user && message.metadata?.modelUsed && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															title: message.metadata.providerUsed,
															children: message.metadata.modelUsed
														})
													]
												})
											]
										}, message.messageId);
									})
								})
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: "gc-chat-bottom",
								ref: bottom,
								children: [
									showLatest && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
										className: "gc-latest",
										"aria-label": "滚动到底部",
										onClick: () => {
											follow.current = true;
											setShowLatest(false);
											if (scroll.current) scroll.current.scrollTop = scroll.current.scrollHeight;
										},
										children: "↓ 回到最新"
									}),
									error && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
										className: "gc-chat-error",
										role: "alert",
										children: [
											error,
											" ",
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setRetry((v) => v + 1),
												children: "重试加载"
											})
										]
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(GroupChatComposer, {
										members,
										value: draft,
										onChange: setDraft,
										onSend: send,
										sending
									})
								]
							})]
						})
					})
				]
			});
		}
		//#endregion
		//#region src/client/layout-push.ts
		/**
		* DSH Group Chat - Layout Push 样式引擎
		* 参考 dsh-better-sidebar 工业级实现：
		* 通过 padding-right 真实推挤 DSH 的 AppFrame 栅格系统，
		* 使得主对话区、原生 Composer 打字输入框、右侧详情栏与滚动条自适应向左收缩，
		* 彻底杜绝遮挡、覆盖或丢失原生页面元素！
		*/
		const LAYOUT_PUSH_CSS = `
/* 1. 给 DSH AppFrame 注入 padding-right，物理推挤主视窗，保持原生输入框和聊天流完好 */
#root [data-dsh-frame],
#root > [data-slot="root"] > div {
  box-sizing: border-box !important;
  padding-right: var(--dsh-group-chat-width, 0px) !important;
  transition: padding-right var(--ds-transition-duration-slow, 0.25s) var(--ds-ease-in-out, cubic-bezier(0.4, 0, 0.2, 1)) !important;
}

/* 2. details 栏（若有开启）自适应向左平移 */
#root [data-dsh-frame] > [data-side="details"],
#root > [data-slot="root"] > div > [data-side="details"] {
  transform: translateX(calc(0px - var(--dsh-group-chat-width, 0px))) !important;
  transition: transform var(--ds-transition-duration-slow, 0.25s) var(--ds-ease-in-out, cubic-bezier(0.4, 0, 0.2, 1)) !important;
}

/* Hide only the native composer seat, never its scroll/view ancestors. */
body[data-dsh-group-chat-active="true"] [data-composer-seat] {
  display: none !important;
}

body[data-dsh-group-chat-active="true"] [data-conversation-scroll] {
  height: 100% !important;
  max-height: 100% !important;
  overflow: hidden !important;
  padding-bottom: 0 !important;
}

body[data-dsh-group-chat-active="true"] [data-conversation-scroll] > div:first-child,
body[data-dsh-group-chat-active="true"] [class*="viewArea"] {
  height: 100% !important;
  max-height: 100% !important;
  display: flex !important;
  flex-direction: column !important;
  flex: 1 1 auto !important;
  overflow: hidden !important;
}

/* 4. 协同侧栏宿主容器 */
.dsh-gc-sidebar-host {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  width: var(--dsh-group-chat-width, 380px);
  height: 100vh;
  z-index: 50;
  background-color: var(--dsw-alias-bg-layer-1, #151518);
  border-left: 1px solid var(--dsw-alias-border-l2, rgba(255, 255, 255, 0.1));
  box-shadow: var(--dsw-shadow-lv2, -2px 0 12px rgba(0, 0, 0, 0.25));
  display: flex;
  flex-direction: column;
  overflow: hidden;
  box-sizing: border-box;
  transition: transform var(--ds-transition-duration-slow, 0.25s) var(--ds-ease-in-out, cubic-bezier(0.4, 0, 0.2, 1));
}

.dsh-gc-sidebar-host[data-collapsed="true"] {
  transform: translateX(100%);
  pointer-events: none;
}
`;
		function injectLayoutPushStyles() {
			const tagId = "dsh-group-chat/layout-push.css";
			if (typeof document !== "undefined" && document.querySelector(`style[data-plugin-css="${tagId}"]`) === null) {
				const style = document.createElement("style");
				style.dataset.plugin = "@dsh-external/dsh-group-chat";
				style.dataset.pluginCss = tagId;
				style.textContent = LAYOUT_PUSH_CSS;
				document.head.appendChild(style);
				return () => style.remove();
			}
			return () => {};
		}
		function updateLayoutPushWidth(widthPx) {
			if (typeof document !== "undefined") document.documentElement.style.setProperty("--dsh-group-chat-width", `${widthPx}px`);
		}
		//#endregion
		//#region src/client/GroupChatModelSettings.tsx
		function labelFor(model) {
			return model.provider && model.model ? `${model.provider} / ${model.model}` : "跟随宿主默认";
		}
		function SearchableModelPicker({ label, value, catalog, allowDefault = false, onChange, onDeleteRecent }) {
			const [open, setOpen] = (0, react.useState)(false), [query, setQuery] = (0, react.useState)("");
			const root = (0, react.useRef)(null), search = (0, react.useRef)(null);
			const id = (0, react.useId)();
			const filtered = (0, react.useMemo)(() => catalog.groups.flatMap((g) => g.models.map((m) => ({
				provider: g.id,
				model: m.id,
				name: m.name,
				groupName: g.name
			}))), [catalog]).filter((item) => `${item.provider} ${item.model} ${item.name} ${item.groupName}`.toLowerCase().includes(query.trim().toLowerCase())).slice(0, 80);
			(0, react.useEffect)(() => {
				if (!open) return;
				search.current?.focus();
				const close = (e) => {
					if (e.target instanceof Node && !root.current?.contains(e.target)) setOpen(false);
				};
				document.addEventListener("pointerdown", close);
				return () => document.removeEventListener("pointerdown", close);
			}, [open]);
			const choose = (m) => {
				onChange(m);
				setOpen(false);
				setQuery("");
			};
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: "gc-model-picker",
				ref: root,
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
						className: "gc-model-label",
						children: label
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "gc-model-trigger",
						"aria-haspopup": "listbox",
						"aria-expanded": open,
						"aria-controls": open ? id : void 0,
						onClick: () => setOpen((v) => !v),
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
							className: "gc-model-trigger-text",
							children: labelFor(value)
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("svg", {
							className: "gc-model-chevron",
							viewBox: "0 0 16 16",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "1.8",
							strokeLinecap: "round",
							strokeLinejoin: "round",
							"aria-hidden": "true",
							children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M4 6l4 4 4-4" })
						})]
					}),
					open && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: "gc-model-popover",
						role: "dialog",
						"aria-label": `${label}模型选择`,
						onKeyDown: (e) => {
							if (e.key === "Escape") {
								e.preventDefault();
								setOpen(false);
							}
							if (e.key === "ArrowDown" || e.key === "ArrowUp") {
								e.preventDefault();
								const items = Array.from(e.currentTarget.querySelectorAll(".gc-model-option"));
								const current = items.indexOf(document.activeElement);
								items[current < 0 ? e.key === "ArrowDown" ? 0 : items.length - 1 : (current + (e.key === "ArrowDown" ? 1 : -1) + items.length) % items.length]?.focus();
							}
							if (e.key === "Enter" && e.target === search.current && filtered[0]) {
								e.preventDefault();
								choose(filtered[0]);
							}
						},
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
							ref: search,
							className: "gc-model-search",
							"aria-label": `搜索${label}模型`,
							placeholder: "搜索 Provider / 模型 ID / 名称…",
							value: query,
							onChange: (e) => setQuery(e.target.value)
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: "gc-model-list",
							id,
							role: "listbox",
							children: [
								allowDefault && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "gc-model-option",
									role: "option",
									onClick: () => choose({
										provider: "",
										model: ""
									}),
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: "跟随宿主默认" }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("small", { children: catalog.current?.model ? labelFor(catalog.current) : "使用当前宿主会话模型" })]
								}),
								catalog.recent.filter((m) => m.provider && m.model).slice(0, 6).map((m, i) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: "gc-model-recent-row",
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
										type: "button",
										className: "gc-model-option gc-model-recent",
										role: "option",
										onClick: () => choose(m),
										children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: labelFor(m) }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("small", { children: "最近使用" })]
									}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
										type: "button",
										className: "gc-model-delete",
										"aria-label": `删除最近模型 ${labelFor(m)}`,
										title: "删除这个最近模型",
										onClick: (e) => {
											e.preventDefault();
											e.stopPropagation();
											onDeleteRecent?.(m);
										},
										children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("svg", {
											viewBox: "0 0 16 16",
											fill: "none",
											stroke: "currentColor",
											strokeWidth: "1.8",
											strokeLinecap: "round",
											"aria-hidden": "true",
											children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M4 4l8 8M12 4l-8 8" })
										})
									})]
								}, `recent-${i}`)),
								filtered.map((item) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "gc-model-option",
									role: "option",
									onClick: () => choose({
										provider: item.provider,
										model: item.model
									}),
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", { children: [
										item.provider,
										" / ",
										item.model
									] }), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("small", { children: [
										item.groupName,
										" · ",
										item.name
									] })]
								}, `${item.provider}/${item.model}`)),
								!filtered.length && !catalog.recent.length && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: "gc-model-empty",
									children: "没有匹配结果，可在下方手动输入完整 ID。"
								})
							]
						})]
					})
				]
			});
		}
		function GroupChatModelSettings({ role, primary, policy, onPrimary, onPolicy }) {
			const [catalog, setCatalog] = (0, react.useState)({
				groups: [],
				recent: []
			});
			const [status, setStatus] = (0, react.useState)("正在加载宿主模型目录…");
			const [reload, setReload] = (0, react.useState)(0);
			(0, react.useEffect)(() => {
				const abort = new AbortController();
				fetch("/dsh-group-chat/api/models", { signal: abort.signal }).then(async (r) => {
					if (!r.ok) throw Error("目录加载失败");
					return r.json();
				}).then((data) => {
					setCatalog(data);
					setStatus(data.groups.some((g) => g.error) ? "部分目录加载失败；仍可手动填写模型 ID。" : "");
				}).catch((e) => {
					if (!abort.signal.aborted) setStatus(e.message + "，可手动输入或重试。");
				});
				return () => abort.abort();
			}, [reload]);
			const deleteRecent = async (model) => {
				setCatalog((prev) => ({
					...prev,
					recent: prev.recent.filter((m) => m.provider !== model.provider || m.model !== model.model)
				}));
				try {
					const response = await fetch("/dsh-group-chat/api/models/recent/delete", {
						method: "POST",
						headers: { "Content-Type": "application/json" },
						body: JSON.stringify(model)
					});
					const data = await response.json();
					if (!response.ok || !data.success) throw Error(data.error || "删除失败");
					setCatalog((prev) => ({
						...prev,
						recent: data.recent || []
					}));
				} catch (e) {
					setStatus(e instanceof Error ? e.message : String(e));
					setReload((v) => v + 1);
				}
			};
			const models = catalog.groups.flatMap((g) => g.models.map((m) => ({
				provider: g.id,
				model: m.id,
				name: m.name,
				groupName: g.name
			})));
			const pattern = {
				backend: /code|coder|codex/i,
				frontend: /code|coder|codex/i,
				qa: /reason|thinking|r1|code/i,
				commander: /reason|thinking|r1/i,
				researcher: /reason|thinking|pro|search/i,
				writer: /chat|instruct|flash/i
			}[role.id] || /chat|instruct/i;
			const suggestions = models.filter((m) => pattern.test(m.model + " " + m.name)).slice(0, 4);
			const manualRow = (label, value, change) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: "gc-model-row",
				children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [
					label,
					" Provider",
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
						"aria-label": `${label} Provider 手动输入`,
						placeholder: "Provider",
						value: value.provider,
						onChange: (e) => change({
							...value,
							provider: e.target.value
						})
					})
				] }), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: ["模型 ID", /* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
					"aria-label": `${label}模型 ID 手动输入`,
					placeholder: "模型 ID",
					value: value.model,
					onChange: (e) => change({
						...value,
						model: e.target.value
					})
				})] })]
			});
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("section", {
				className: "gc-model-settings",
				"aria-label": "角色模型与回退设置",
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("style", { children: `.gc-model-settings{border-top:1px solid var(--dsw-alias-border-l2,#ffffff1f);padding-top:12px;font-size:12px}.gc-model-settings h3{font-size:13px;margin:0 0 8px}.gc-model-settings p{color:var(--dsw-alias-label-secondary,#aaa);font-size:11px;line-height:1.6}.gc-model-row{display:grid;grid-template-columns:minmax(100px,1fr) minmax(140px,2fr);gap:8px}.gc-model-settings label{display:block;min-width:0}.gc-model-settings input,.gc-model-settings select{display:block;box-sizing:border-box;width:100%;margin:4px 0 8px;padding:7px 9px;border:1px solid var(--dsw-alias-border-l2,#ffffff2b);border-radius:8px;background:var(--dsw-alias-bg-base,#151519);color:inherit;font:inherit}.gc-model-settings input:focus-visible,.gc-model-trigger:focus-visible,.gc-model-search:focus-visible,.gc-model-settings button:focus-visible{outline:2px solid var(--dsw-alias-state-business-primary,#4d6bfe);outline-offset:2px}.gc-model-settings button{padding:5px 9px;margin:2px;border:1px solid var(--dsw-alias-border-l2,#ffffff26);border-radius:8px;background:var(--dsw-alias-bg-layer-1,#202025);color:inherit;font:inherit;cursor:pointer}.gc-model-settings button:hover{background:var(--dsw-alias-bg-layer-2,#2b2b31)}.gc-model-settings button:disabled{opacity:.4;cursor:default}.gc-fallback-item{padding:9px;margin-top:8px;border:1px solid var(--dsw-alias-border-l1,#ffffff17);border-radius:10px;background:color-mix(in oklab,var(--dsw-alias-bg-layer-2,#1b1b1f) 72%,transparent)}.gc-model-numbers{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.gc-model-picker{position:relative;margin:7px 0}.gc-model-label{display:block;color:var(--dsw-alias-label-secondary,#cbd5e1);font-size:11px;margin-bottom:5px}.gc-model-trigger{display:flex!important;align-items:center;justify-content:space-between;gap:8px;width:100%;min-height:34px;text-align:left}.gc-model-trigger-text{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.gc-model-chevron{width:16px;height:16px;display:block;opacity:.75;transition:transform .15s ease}.gc-model-trigger[aria-expanded=true] .gc-model-chevron{transform:rotate(180deg)}.gc-model-popover{position:absolute;z-index:10002;left:0;right:0;top:calc(100% + 6px);padding:8px;border:1px solid var(--dsw-alias-border-l2,#ffffff2b);border-radius:14px;background:var(--dsw-alias-bg-layer-1,#202025);box-shadow:0 18px 48px #0008}.gc-model-search{margin:0 0 7px!important}.gc-model-list{max-height:260px;overflow:auto;display:flex;flex-direction:column;gap:2px}.gc-model-recent-row{display:grid;grid-template-columns:1fr 28px;align-items:stretch;border-radius:10px}.gc-model-recent-row:hover{background:var(--dsw-alias-bg-layer-2,#2b2b31)}.gc-model-option{display:flex!important;flex-direction:column;align-items:flex-start;width:100%;text-align:left;margin:0!important;background:transparent!important;border:0!important}.gc-model-option span{font-size:12px}.gc-model-option small{font-size:10px;color:var(--dsw-alias-label-tertiary,#9696a3);max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.gc-model-delete{display:grid!important;place-items:center;width:26px;height:26px;align-self:center;margin:0!important;border:0!important;background:transparent!important;color:var(--dsw-alias-label-tertiary,#999)!important;border-radius:8px}.gc-model-delete svg{width:13px;height:13px}.gc-model-delete:hover{color:#fca5a5!important;background:rgba(248,113,113,.12)!important}.gc-model-recent span:before{content:'最近 · ';color:var(--dsw-alias-state-business-primary,#4d6bfe)}.gc-recent-panel,.gc-suggestion-panel{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0 10px}.gc-recent-chip-row{display:grid;grid-template-columns:minmax(0,1fr) 28px;align-items:center;max-width:100%;border:1px solid var(--dsw-alias-border-l2,#ffffff26);border-radius:10px;overflow:hidden;background:var(--dsw-alias-bg-layer-1,#202025)}.gc-recent-chip-row:hover{background:var(--dsw-alias-bg-layer-2,#2b2b31)}.gc-recent-chip{min-width:0;max-width:100%;padding:5px 8px!important;margin:0!important;border:0!important;border-radius:0!important;background:transparent!important;overflow:hidden;text-align:left}.gc-recent-chip>span,.gc-suggestion-chip>span{display:block;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.gc-recent-delete{width:24px!important;height:24px!important;margin:0 4px 0 0!important}.gc-suggestion-chip{max-width:100%;display:inline-flex!important}.gc-suggestion-chip span{display:block}.gc-model-empty{padding:12px;color:var(--dsw-alias-label-tertiary,#999);font-size:11px}` }),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("h3", { children: "主模型" }),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(SearchableModelPicker, {
						label: "主模型",
						value: primary,
						catalog,
						allowDefault: true,
						onChange: onPrimary,
						onDeleteRecent: deleteRecent
					}),
					manualRow("主模型", primary, onPrimary),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("p", { children: [
						"下拉数据来自插件服务端调用 DSH 官方模型目录 ctx.llm.listProviders/listModels；两项留空时跟随宿主",
						catalog.current?.model ? `：${catalog.current.provider} / ${catalog.current.model}` : "默认模型",
						"。"
					] }),
					status && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("p", {
						role: "status",
						children: [
							status,
							" ",
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setReload((v) => v + 1),
								children: "刷新目录"
							})
						]
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: "最近使用的模型 ID（最多 6 条）：" }),
					catalog.recent.filter((m) => m.provider && m.model).length ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: "gc-recent-panel",
						children: catalog.recent.filter((m) => m.provider && m.model).slice(0, 6).map((m) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: "gc-recent-chip-row",
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								type: "button",
								className: "gc-recent-chip",
								onClick: () => onPrimary(m),
								title: labelFor(m),
								children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: labelFor(m) })
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								type: "button",
								className: "gc-model-delete gc-recent-delete",
								"aria-label": `删除最近模型 ${labelFor(m)}`,
								title: "删除这个最近模型",
								onClick: (e) => {
									e.preventDefault();
									e.stopPropagation();
									deleteRecent(m);
								},
								children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("svg", {
									viewBox: "0 0 16 16",
									fill: "none",
									stroke: "currentColor",
									strokeWidth: "1.8",
									strokeLinecap: "round",
									"aria-hidden": "true",
									children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M4 4l8 8M12 4l-8 8" })
								})
							})]
						}, m.provider + "/" + m.model))
					}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: "暂无最近模型记录。" }),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("p", { children: [
						"角色建议：按模型名称匹配「",
						role.title || role.id,
						"」职责，仅供选择参考。"
					] }),
					suggestions.length ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: "gc-suggestion-panel",
						children: suggestions.map((m) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							type: "button",
							className: "gc-suggestion-chip",
							onClick: () => onPrimary({
								provider: m.provider,
								model: m.model
							}),
							title: `${m.provider} / ${m.model}`,
							children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", { children: [
								m.provider,
								" / ",
								m.model
							] })
						}, m.provider + "/" + m.model))
					}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: "当前目录没有明确匹配项。" }),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("h3", {
						style: { marginTop: 14 },
						children: "回退模型 · 按顺序尝试"
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: "主模型失败并耗尽重试后，依次切换下列模型。" }),
					policy.fallbackModels.map((m, i) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: "gc-fallback-item",
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)(SearchableModelPicker, {
								label: `回退 ${i + 1}`,
								value: m,
								catalog,
								onChange: (value) => onPolicy({
									...policy,
									fallbackModels: policy.fallbackModels.map((old, j) => j === i ? value : old)
								}),
								onDeleteRecent: deleteRecent
							}),
							manualRow(`回退 ${i + 1}`, m, (value) => onPolicy({
								...policy,
								fallbackModels: policy.fallbackModels.map((old, j) => j === i ? value : old)
							})),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: i === 0,
								onClick: () => {
									const next = [...policy.fallbackModels];
									[next[i - 1], next[i]] = [next[i], next[i - 1]];
									onPolicy({
										...policy,
										fallbackModels: next
									});
								},
								children: "上移"
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onPolicy({
									...policy,
									fallbackModels: policy.fallbackModels.filter((_, j) => j !== i)
								}),
								children: ["移除回退 ", i + 1]
							})
						]
					}, i)),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: policy.fallbackModels.length >= 5,
						onClick: () => onPolicy({
							...policy,
							fallbackModels: [...policy.fallbackModels, {
								provider: "",
								model: ""
							}]
						}),
						children: "＋ 添加回退模型"
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: "gc-model-numbers",
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: ["每模型重试次数", /* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
								"aria-label": "每模型重试次数",
								type: "number",
								min: 0,
								max: 5,
								value: policy.maxRetriesPerModel,
								onChange: (e) => onPolicy({
									...policy,
									maxRetriesPerModel: Number(e.target.value)
								})
							})] }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: ["退避毫秒", /* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
								"aria-label": "退避毫秒",
								type: "number",
								min: 0,
								max: 6e4,
								value: policy.retryBackoffMs,
								onChange: (e) => onPolicy({
									...policy,
									retryBackoffMs: Number(e.target.value)
								})
							})] }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: ["超时毫秒", /* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
								"aria-label": "超时毫秒",
								type: "number",
								min: 1e3,
								max: 6e5,
								value: policy.timeoutMs,
								onChange: (e) => onPolicy({
									...policy,
									timeoutMs: Number(e.target.value)
								})
							})] })
						]
					})
				]
			});
		}
		//#endregion
		//#region src/client/GroupChatRoleEditor.tsx
		function GroupChatRoleEditor({ editingAgent, roomId, onClose, onSaved }) {
			const [agentForm, setAgentForm] = (0, react.useState)({
				name: editingAgent.name,
				avatar: editingAgent.avatar,
				title: editingAgent.title || "",
				roleDescription: editingAgent.roleDescription,
				systemPrompt: editingAgent.systemPrompt || "",
				provider: editingAgent.llmConfig?.provider || "",
				model: editingAgent.llmConfig?.model || "",
				canWriteScratchpad: editingAgent.permissions?.canWriteScratchpad ?? false,
				canApproveWorkflow: editingAgent.permissions?.canApproveWorkflow ?? false
			});
			const [policy, setPolicy] = (0, react.useState)(editingAgent.resiliencePolicy || {
				fallbackModels: [],
				maxRetriesPerModel: 2,
				retryBackoffMs: 1e3,
				timeoutMs: 3e4
			});
			const [saveError, setSaveError] = (0, react.useState)("");
			const [saving, setSaving] = (0, react.useState)(false);
			const dialogRef = (0, react.useRef)(null);
			(0, react.useEffect)(() => {
				const previous = document.activeElement;
				dialogRef.current?.querySelector("button")?.focus();
				return () => previous?.isConnected && previous.focus();
			}, []);
			const fileInputRef = (0, react.useRef)(null);
			const handleAvatarFileUpload = (e) => {
				const file = e.target.files?.[0];
				if (!file) return;
				const reader = new FileReader();
				reader.onload = (uploadEvent) => {
					const result = uploadEvent.target?.result;
					if (typeof result === "string") setAgentForm((prev) => ({
						...prev,
						avatar: result
					}));
				};
				reader.readAsDataURL(file);
			};
			const handleSaveAgent = async () => {
				if (!editingAgent || saving) return;
				setSaving(true);
				setSaveError("");
				try {
					const res = await fetch("/dsh-group-chat/api/agent/update", {
						method: "POST",
						headers: { "Content-Type": "application/json" },
						body: JSON.stringify({
							roomId,
							agentId: editingAgent.id,
							name: agentForm.name,
							avatar: agentForm.avatar,
							title: agentForm.title,
							roleDescription: agentForm.roleDescription,
							systemPrompt: agentForm.systemPrompt,
							llmConfig: {
								provider: agentForm.provider.trim(),
								model: agentForm.model.trim()
							},
							resiliencePolicy: {
								...policy,
								fallbackModels: policy.fallbackModels.map((m) => ({
									...m,
									provider: m.provider.trim(),
									model: m.model.trim()
								}))
							},
							permissions: {
								canWriteScratchpad: agentForm.canWriteScratchpad,
								canApproveWorkflow: agentForm.canApproveWorkflow
							}
						})
					});
					const data = await res.json();
					if (!res.ok || !data.success) throw Error(data.error || "保存失败");
					if (res.ok) {
						onClose();
						onSaved();
					}
				} catch (err) {
					setSaveError(err instanceof Error ? err.message : String(err));
				} finally {
					setSaving(false);
				}
			};
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, react_jsx_runtime.jsx)("style", { children: `[aria-label="编辑特遣角色属性"]>div,[aria-label="编辑特遣角色属性"]>section{flex-shrink:0;}` }),
				/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
					type: "file",
					ref: fileInputRef,
					onChange: handleAvatarFileUpload,
					accept: "image/*",
					style: { display: "none" }
				}),
				/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
					style: {
						position: "fixed",
						top: 0,
						left: 0,
						right: 0,
						bottom: 0,
						backgroundColor: "rgba(0, 0, 0, 0.65)",
						display: "flex",
						alignItems: "center",
						justifyContent: "center",
						zIndex: 9999
					},
					children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						ref: dialogRef,
						onKeyDown: (e) => {
							if (e.key === "Escape" && !saving) {
								e.preventDefault();
								onClose();
							}
							if (e.key === "Tab") {
								const nodes = Array.from(e.currentTarget.querySelectorAll("button:not(:disabled),input:not(:disabled),textarea,select")).filter((el) => el.getClientRects().length);
								const first = nodes[0], last = nodes[nodes.length - 1];
								if (e.shiftKey && document.activeElement === first) {
									e.preventDefault();
									last?.focus();
								}
								if (!e.shiftKey && document.activeElement === last) {
									e.preventDefault();
									first?.focus();
								}
							}
						},
						role: "dialog",
						"aria-modal": "true",
						"aria-label": "编辑特遣角色属性",
						style: {
							width: "min(620px, calc(100vw - 32px))",
							maxHeight: "calc(100dvh - 40px)",
							boxSizing: "border-box",
							overflowY: "auto",
							backgroundColor: "var(--dsw-alias-bg-layer-1, #151518)",
							border: "1px solid var(--dsw-alias-border-l2, rgba(255,255,255,0.12))",
							borderRadius: "12px",
							padding: "20px",
							display: "flex",
							flexDirection: "column",
							gap: "12px",
							boxShadow: "var(--dsw-shadow-lv3, 0 12px 32px rgba(0,0,0,0.5))"
						},
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								style: {
									display: "flex",
									justifyContent: "space-between",
									alignItems: "center"
								},
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
									style: {
										fontSize: "15px",
										fontWeight: 600
									},
									children: [
										"编辑特遣角色属性 (",
										editingAgent.id,
										")"
									]
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
									onClick: () => onClose(),
									style: {
										background: "transparent",
										border: "none",
										color: "#94a3b8",
										fontSize: "16px",
										cursor: "pointer"
									},
									children: "✕"
								})]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								style: {
									display: "flex",
									alignItems: "center",
									gap: "14px",
									padding: "10px 0"
								},
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									onClick: () => fileInputRef.current?.click(),
									title: "点击上传本地头像图片",
									style: {
										width: "54px",
										height: "54px",
										borderRadius: "50%",
										backgroundColor: editingAgent.color || "#4d6bfe",
										display: "flex",
										alignItems: "center",
										justifyContent: "center",
										cursor: "pointer",
										overflow: "hidden",
										fontSize: "24px",
										border: "2px dashed rgba(255,255,255,0.3)"
									},
									children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(AvatarBadge, {
										avatar: agentForm.avatar,
										alt: "avatar",
										style: {
											width: "100%",
											height: "100%",
											display: "grid",
											placeItems: "center"
										}
									})
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => fileInputRef.current?.click(),
									style: {
										backgroundColor: "var(--dsw-alias-bg-layer-2, #1b1b1f)",
										border: "1px solid var(--dsw-alias-border-l2, rgba(255,255,255,0.12))",
										color: "var(--dsw-alias-label-primary, #fff)",
										borderRadius: "6px",
										padding: "4px 10px",
										fontSize: "11px",
										cursor: "pointer"
									},
									children: "📁 上传本地头像图片"
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									style: {
										fontSize: "10px",
										color: "var(--dsw-alias-label-tertiary, #94a3b8)",
										marginTop: "4px"
									},
									children: "支持 PNG、JPG、WebP 格式，将自动保存为角色自定义头像"
								})] })]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								style: {
									display: "grid",
									gridTemplateColumns: "1fr 1fr",
									gap: "10px"
								},
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("label", {
									style: {
										fontSize: "11px",
										color: "var(--dsw-alias-label-secondary, #cbd5e1)"
									},
									children: "角色显示姓名"
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
									type: "text",
									value: agentForm.name,
									onChange: (e) => setAgentForm({
										...agentForm,
										name: e.target.value
									}),
									style: {
										width: "100%",
										padding: "6px 8px",
										borderRadius: "6px",
										background: "var(--dsw-alias-bg-base, #0d0d11)",
										border: "1px solid rgba(255,255,255,0.1)",
										color: "#fff",
										fontSize: "12px",
										marginTop: "4px",
										boxSizing: "border-box"
									}
								})] }), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("label", {
									style: {
										fontSize: "11px",
										color: "var(--dsw-alias-label-secondary, #cbd5e1)"
									},
									children: "角色头衔/职称"
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
									type: "text",
									value: agentForm.title,
									onChange: (e) => setAgentForm({
										...agentForm,
										title: e.target.value
									}),
									style: {
										width: "100%",
										padding: "6px 8px",
										borderRadius: "6px",
										background: "var(--dsw-alias-bg-base, #0d0d11)",
										border: "1px solid rgba(255,255,255,0.1)",
										color: "#fff",
										fontSize: "12px",
										marginTop: "4px",
										boxSizing: "border-box"
									}
								})] })]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("label", {
								style: {
									fontSize: "11px",
									color: "var(--dsw-alias-label-secondary, #cbd5e1)"
								},
								children: "专长职责描述"
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("textarea", {
								value: agentForm.roleDescription,
								onChange: (e) => setAgentForm({
									...agentForm,
									roleDescription: e.target.value
								}),
								style: {
									width: "100%",
									height: "50px",
									padding: "6px 8px",
									borderRadius: "6px",
									background: "var(--dsw-alias-bg-base, #0d0d11)",
									border: "1px solid rgba(255,255,255,0.1)",
									color: "#fff",
									fontSize: "11px",
									marginTop: "4px",
									resize: "none",
									boxSizing: "border-box"
								}
							})] }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("label", {
								style: {
									fontSize: "11px",
									color: "var(--dsw-alias-label-secondary, #cbd5e1)"
								},
								children: "角色系统设定提示词 (System Prompt)"
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("textarea", {
								value: agentForm.systemPrompt,
								onChange: (e) => setAgentForm({
									...agentForm,
									systemPrompt: e.target.value
								}),
								style: {
									width: "100%",
									height: "80px",
									padding: "6px 8px",
									borderRadius: "6px",
									background: "var(--dsw-alias-bg-base, #0d0d11)",
									border: "1px solid rgba(255,255,255,0.1)",
									color: "#fff",
									fontSize: "11px",
									marginTop: "4px",
									resize: "none",
									boxSizing: "border-box"
								}
							})] }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)(GroupChatModelSettings, {
								role: editingAgent,
								primary: {
									provider: agentForm.provider,
									model: agentForm.model
								},
								policy,
								onPrimary: (m) => setAgentForm((prev) => ({
									...prev,
									...m
								})),
								onPolicy: setPolicy
							}),
							saveError && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								role: "alert",
								style: {
									color: "#fca5a5",
									fontSize: 12
								},
								children: saveError
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								style: {
									display: "flex",
									gap: "20px",
									padding: "6px 0"
								},
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", {
									style: {
										display: "flex",
										alignItems: "center",
										gap: "6px",
										fontSize: "11px",
										cursor: "pointer"
									},
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: agentForm.canWriteScratchpad,
										onChange: (e) => setAgentForm({
											...agentForm,
											canWriteScratchpad: e.target.checked
										})
									}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: "允许编辑共享黑板 (Write Scratchpad)" })]
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", {
									style: {
										display: "flex",
										alignItems: "center",
										gap: "6px",
										fontSize: "11px",
										cursor: "pointer"
									},
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: agentForm.canApproveWorkflow,
										onChange: (e) => setAgentForm({
											...agentForm,
											canApproveWorkflow: e.target.checked
										})
									}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: "具备工作流审核审批特权 (Approve Workflow)" })]
								})]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								style: {
									display: "flex",
									justifyContent: "flex-end",
									gap: "8px",
									marginTop: "6px"
								},
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => onClose(),
									style: {
										backgroundColor: "transparent",
										border: "1px solid rgba(255,255,255,0.15)",
										color: "#fff",
										borderRadius: "6px",
										padding: "6px 14px",
										fontSize: "12px",
										cursor: "pointer"
									},
									children: "取消"
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
									type: "button",
									disabled: saving,
									onClick: handleSaveAgent,
									style: {
										backgroundColor: "var(--dsw-alias-state-business-primary, #4d6bfe)",
										color: "#fff",
										border: "none",
										borderRadius: "6px",
										padding: "6px 16px",
										fontSize: "12px",
										cursor: "pointer",
										fontWeight: 600
									},
									children: saving ? "正在保存…" : "保存修改"
								})]
							})
						]
					})
				})
			] });
		}
		//#endregion
		//#region src/client/GroupChatSideDock.tsx
		const SIDEBAR_DEFAULT_WIDTH = 380;
		function formatDuration(ms = 0) {
			const seconds = Math.max(0, Math.round(ms / 1e3));
			const minutes = Math.floor(seconds / 60);
			const rest = seconds % 60;
			return minutes ? `${minutes}m${rest}s` : `${rest}s`;
		}
		function formatTokens(n = 0) {
			if (n >= 1e6) return `${(n / 1e6).toFixed(n >= 1e7 ? 1 : 2)}M`;
			if (n >= 1e3) return `${(n / 1e3).toFixed(n >= 1e4 ? 1 : 2)}K`;
			return `${Math.round(n)}`;
		}
		function metricLine(calls = 0, m) {
			const input = (m?.inputTokens || 0) + (m?.cacheReadTokens || 0) + (m?.cacheWriteTokens || 0);
			const output = m?.outputTokens || 0;
			const totalInputForCache = (m?.inputTokens || 0) + (m?.cacheReadTokens || 0);
			const cacheHit = totalInputForCache ? Math.round((m?.cacheReadTokens || 0) / totalInputForCache * 100) : 0;
			const first = m?.firstTokenCount ? `${(m.firstTokenMsTotal / m.firstTokenCount / 1e3).toFixed(1)}s` : "—";
			const llmSeconds = (m?.llmMs || 0) / 1e3;
			const tokPerSec = llmSeconds > 0 ? Math.round(output / llmSeconds) : 0;
			return `${calls} 轮 · ${m?.stepCount || 0} 步  LLM ${formatDuration(m?.llmMs)} · 工具调用 ${formatDuration(m?.toolMs)}  首 token 平均 ${first} · ${tokPerSec} tok/s  缓存命中 ${cacheHit}%  输入 ${formatTokens(input)} tok · 输出 ${formatTokens(output)} tok`;
		}
		function mergeMetrics(items) {
			return items.reduce((acc, m) => ({
				turnCount: acc.turnCount + (m?.turnCount || 0),
				stepCount: acc.stepCount + (m?.stepCount || 0),
				llmMs: acc.llmMs + (m?.llmMs || 0),
				toolMs: acc.toolMs + (m?.toolMs || 0),
				firstTokenMsTotal: acc.firstTokenMsTotal + (m?.firstTokenMsTotal || 0),
				firstTokenCount: acc.firstTokenCount + (m?.firstTokenCount || 0),
				inputTokens: acc.inputTokens + (m?.inputTokens || 0),
				outputTokens: acc.outputTokens + (m?.outputTokens || 0),
				cacheReadTokens: acc.cacheReadTokens + (m?.cacheReadTokens || 0),
				cacheWriteTokens: acc.cacheWriteTokens + (m?.cacheWriteTokens || 0)
			}), {
				turnCount: 0,
				stepCount: 0,
				llmMs: 0,
				toolMs: 0,
				firstTokenMsTotal: 0,
				firstTokenCount: 0,
				inputTokens: 0,
				outputTokens: 0,
				cacheReadTokens: 0,
				cacheWriteTokens: 0
			});
		}
		/**
		* 侧边栏辅助副屏 (Companion HUD)
		* 定位：区别于全屏主对话输入区，侧栏仅提供轻量、高密度的【拓扑监控 + 共享黑板 + 成员账本】，不再重复聊天发送入口。
		*/
		function GroupChatSideDock() {
			const [isOpen, setIsOpen] = (0, react.useState)(false);
			const [editingAgent, setEditingAgent] = (0, react.useState)(null);
			const [managementError, setManagementError] = (0, react.useState)("");
			const [room, setRoom] = (0, react.useState)(null);
			const [ledger, setLedger] = (0, react.useState)(null);
			const [scratchpadDraft, setScratchpadDraft] = (0, react.useState)("");
			const [isEditingScratchpad, setIsEditingScratchpad] = (0, react.useState)(false);
			const [activeTab, setActiveTab] = (0, react.useState)("workflow");
			const [modeHelpOpen, setModeHelpOpen] = (0, react.useState)(false);
			const [themeBrief, setThemeBrief] = (0, react.useState)("沙雕但靠谱的互联网项目小队，说人话、有梗、能交付；顺手按任务生成工作流");
			const [themeBusy, setThemeBusy] = (0, react.useState)(false);
			const [themeDraft, setThemeDraft] = (0, react.useState)([]);
			const [workflowDraft, setWorkflowDraft] = (0, react.useState)(null);
			const fetchRoomData = async () => {
				try {
					const res = await fetch("/dsh-group-chat/api/room?id=dev-team-alpha");
					if (!res.ok) return;
					const data = await res.json();
					if (data.room) {
						setRoom(data.room);
						setScratchpadDraft(data.room.scratchpad || "");
					}
					if (data.ledger) setLedger(data.ledger);
				} catch (err) {
					console.error("[GroupChatDock] fetch error:", err);
				}
			};
			(0, react.useEffect)(() => {
				fetchRoomData();
				return subscribeGroupChat((e) => {
					try {
						const data = JSON.parse(e.data);
						if (data.type === "room:updated" || data.type === "stage:advanced" || data.type === "stage:rejected") setRoom(data.payload);
						else if (data.type === "scratchpad:updated") setScratchpadDraft(data.payload.scratchpad);
						else if (data.type === "message:new") fetchRoomData();
					} catch {}
				});
			}, []);
			(0, react.useEffect)(() => {
				if (isOpen) updateLayoutPushWidth(SIDEBAR_DEFAULT_WIDTH);
				else updateLayoutPushWidth(0);
			}, [isOpen]);
			(0, react.useEffect)(() => {
				const handleKey = (e) => {
					if (e.key === "Escape" && isOpen) setIsOpen(false);
				};
				window.addEventListener("keydown", handleKey);
				return () => window.removeEventListener("keydown", handleKey);
			}, [isOpen]);
			const handleSaveScratchpad = async () => {
				try {
					await fetch("/dsh-group-chat/api/scratchpad", {
						method: "POST",
						headers: { "Content-Type": "application/json" },
						body: JSON.stringify({
							roomId: room?.roomId || "dev-team-alpha",
							scratchpad: scratchpadDraft,
							operatorRoleId: "commander"
						})
					});
					setIsEditingScratchpad(false);
				} catch (err) {
					console.error("Save scratchpad error:", err);
				}
			};
			const handleApproveStage = async () => {
				try {
					await fetch("/dsh-group-chat/api/workflow/action", {
						method: "POST",
						headers: { "Content-Type": "application/json" },
						body: JSON.stringify({
							roomId: room?.roomId || "dev-team-alpha",
							action: "advance",
							approverRoleId: "commander",
							summary: "指挥官审核通过，批准进入下一阶段"
						})
					});
					fetchRoomData();
				} catch (err) {
					console.error("Approve error:", err);
				}
			};
			const updateRoom = async (path, data) => {
				setManagementError("");
				try {
					const response = await fetch("/dsh-group-chat/api/" + path, {
						method: "POST",
						headers: { "Content-Type": "application/json" },
						body: JSON.stringify({
							roomId: room?.roomId || "dev-team-alpha",
							...data
						})
					});
					const result = await response.json();
					if (!response.ok || result.success === false) throw Error(result.error || result.message || "更新失败");
					await fetchRoomData();
				} catch (e) {
					setManagementError(e instanceof Error ? e.message : String(e));
				}
			};
			const generateThemeDraft = async (apply = false) => {
				setManagementError("");
				setThemeBusy(true);
				try {
					const response = await fetch(`/dsh-group-chat/api/theme/${apply ? "apply-draft" : "draft"}`, {
						method: "POST",
						headers: { "Content-Type": "application/json" },
						body: JSON.stringify({
							roomId: room?.roomId || "dev-team-alpha",
							brief: themeBrief,
							members: themeDraft,
							workflow: workflowDraft
						})
					});
					const result = await response.json();
					if (!response.ok || result.success === false) throw Error(result.error || result.message || "主题生成失败");
					if (apply) {
						setThemeDraft([]);
						setWorkflowDraft(null);
						await fetchRoomData();
					} else {
						setThemeDraft(result.members || []);
						setWorkflowDraft(result.workflow || null);
					}
				} catch (e) {
					setManagementError(e instanceof Error ? e.message : String(e));
				} finally {
					setThemeBusy(false);
				}
			};
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, react_jsx_runtime.jsx)("style", { children: `.gc-roster-avatar{width:22px;height:22px;border-radius:7px;display:inline-grid;place-items:center;flex-shrink:0;font-size:14px;color:var(--dsw-alias-state-business-primary,#4d6bfe);background:var(--dsw-alias-bg-layer-3,rgba(255,255,255,0.06));}` }),
				editingAgent && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(GroupChatRoleEditor, {
					editingAgent,
					roomId: room?.roomId || "dev-team-alpha",
					onClose: () => setEditingAgent(null),
					onSaved: () => void fetchRoomData()
				}),
				modeHelpOpen && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
					role: "dialog",
					"aria-modal": "true",
					"aria-label": "调度模式 QA 说明",
					onClick: () => setModeHelpOpen(false),
					style: {
						position: "fixed",
						inset: 0,
						zIndex: 1e3,
						display: "grid",
						placeItems: "center",
						background: "rgba(0,0,0,0.52)",
						pointerEvents: "auto"
					},
					children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						onClick: (e) => e.stopPropagation(),
						style: {
							width: "min(560px, calc(100vw - 32px))",
							maxHeight: "calc(100vh - 80px)",
							overflowY: "auto",
							border: "1px solid var(--dsw-alias-border-l2, rgba(255,255,255,0.14))",
							borderRadius: 16,
							background: "var(--dsw-alias-bg-layer-1, #1f1f23)",
							boxShadow: "var(--dsw-shadow-lv3, 0 20px 60px rgba(0,0,0,0.45))",
							color: "var(--dsw-alias-label-primary,#f8fafc)"
						},
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							style: {
								display: "flex",
								alignItems: "center",
								justifyContent: "space-between",
								padding: "14px 16px",
								borderBottom: "1px solid var(--dsw-alias-border-l1, rgba(255,255,255,0.08))"
							},
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								style: {
									fontSize: 14,
									fontWeight: 700
								},
								children: "调度模式 QA 速查"
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								style: {
									fontSize: 11,
									color: "var(--dsw-alias-label-tertiary,#94a3b8)",
									marginTop: 2
								},
								children: "不知道怎么用时，直接按场景选下面四种。"
							})] }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setModeHelpOpen(false),
								"aria-label": "关闭调度模式说明",
								style: {
									width: 28,
									height: 28,
									borderRadius: 8,
									border: "1px solid var(--dsw-alias-border-l2, rgba(255,255,255,0.14))",
									background: "var(--dsw-alias-bg-layer-2,#202025)",
									color: "inherit",
									cursor: "pointer"
								},
								children: "×"
							})]
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							style: {
								display: "grid",
								gap: 10,
								padding: "14px 16px",
								fontSize: 12,
								lineHeight: 1.55
							},
							children: [[
								["仅 @ 角色", "你明确 @ 谁，谁才发言；不 @ 就只入库。适合精准点名单问，例如：@前端工程师 优化这个下拉。"],
								["工作流", "按右侧五阶段推进当前任务；当前阶段责任人先执行，阶段产物需要总指挥审核后进入下一阶段。适合完整项目、需求→实现→审计→文档。"],
								["主持人调度", "每次人类消息先交给总指挥拆解，再由总指挥安排后续角色。适合你不想自己点名、但仍希望有人把控节奏。"],
								["自由讨论", "所有角色都收到主题并自行判断是否相关；无关角色返回 NO_REPLY 被静默。适合头脑风暴，但调用量会更多。"]
							].map(([title, body]) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								style: {
									padding: "10px 12px",
									borderRadius: 12,
									background: "var(--dsw-alias-bg-layer-2,#242428)",
									border: "1px solid var(--dsw-alias-border-l1, rgba(255,255,255,0.08))"
								},
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									style: {
										fontWeight: 700,
										marginBottom: 4
									},
									children: title
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									style: { color: "var(--dsw-alias-label-secondary,#cbd5e1)" },
									children: body
								})]
							}, title)), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								style: {
									padding: "10px 12px",
									borderRadius: 12,
									background: "rgba(16,185,129,0.08)",
									border: "1px solid rgba(16,185,129,0.24)",
									color: "var(--dsw-alias-label-secondary,#cbd5e1)"
								},
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("b", {
										style: { color: "var(--dsw-alias-label-primary,#f8fafc)" },
										children: "工作区隔离："
									}),
									"角色编辑、模型/回退模型与调度状态保存在当前 DSH 工作区的 ",
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", { children: ".pm-workflow/dsh-group-chat/" }),
									"，不是全局配置；换工作区不会串配置。"
								]
							})]
						})]
					})
				}),
				!isOpen && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					onClick: () => setIsOpen(true),
					title: "展开特遣协同副屏 (实时监控 HUD)",
					style: {
						position: "fixed",
						top: "72px",
						right: "0px",
						zIndex: 49,
						pointerEvents: "auto",
						display: "flex",
						alignItems: "center",
						gap: "6px",
						padding: "5px 10px",
						backgroundColor: "var(--dsw-alias-bg-layer-2, #1b1b1f)",
						border: "1px solid var(--dsw-alias-border-l2, rgba(255, 255, 255, 0.12))",
						borderRight: "none",
						borderTopLeftRadius: "16px",
						borderBottomLeftRadius: "16px",
						boxShadow: "var(--dsw-shadow-lv2, 0 4px 12px rgba(0,0,0,0.3))",
						cursor: "pointer",
						userSelect: "none",
						color: "var(--dsw-alias-label-primary, #f8fafc)",
						fontSize: "11px",
						fontWeight: 500,
						transition: "transform 0.15s ease"
					},
					onMouseEnter: (e) => e.currentTarget.style.transform = "translateX(-2px)",
					onMouseLeave: (e) => e.currentTarget.style.transform = "translateX(0)",
					children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
							style: { fontSize: "13px" },
							children: "🧭"
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: "特遣副屏" }),
						room?.workflow && !room.workflow.isCompleted && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { style: {
							width: "6px",
							height: "6px",
							borderRadius: "50%",
							backgroundColor: "var(--dsw-alias-state-business-primary, #4d6bfe)"
						} })
					]
				}),
				/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					className: "dsh-gc-sidebar-host",
					"aria-label": "群聊管理侧栏",
					"aria-hidden": !isOpen,
					inert: !isOpen,
					"data-collapsed": !isOpen,
					style: {
						pointerEvents: isOpen ? "auto" : "none",
						display: "flex",
						flexDirection: "column",
						backgroundColor: "var(--dsw-alias-bg-layer-1, #151518)"
					},
					children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							style: {
								padding: "12px 14px",
								borderBottom: "1px solid var(--dsw-alias-border-l2, rgba(255,255,255,0.08))",
								display: "flex",
								alignItems: "center",
								justifyContent: "space-between"
							},
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								style: {
									display: "flex",
									alignItems: "center",
									gap: "8px"
								},
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									style: { fontSize: "16px" },
									children: "🧭"
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									style: {
										fontSize: "13px",
										fontWeight: 600,
										color: "var(--dsw-alias-label-primary, #f8fafc)"
									},
									children: "特遣监控室 (HUD)"
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									style: {
										fontSize: "10px",
										color: "var(--dsw-alias-label-tertiary, #94a3b8)"
									},
									children: room?.title || "群聊设置"
								})] })]
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								onClick: () => setIsOpen(false),
								style: {
									background: "transparent",
									border: "none",
									color: "var(--dsw-alias-label-secondary, #94a3b8)",
									cursor: "pointer",
									fontSize: "14px",
									padding: "4px",
									borderRadius: "4px"
								},
								children: "✕"
							})]
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							style: {
								padding: "10px 14px",
								display: "grid",
								gridTemplateColumns: "auto minmax(74px,1fr) auto minmax(78px,1fr) 28px",
								columnGap: 8,
								rowGap: 6,
								fontSize: 11,
								alignItems: "center",
								whiteSpace: "nowrap"
							},
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									style: {
										color: "var(--dsw-alias-label-secondary, #cbd5e1)",
										height: 30,
										display: "inline-flex",
										alignItems: "center"
									},
									children: "角色主题"
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
									style: {
										position: "relative",
										display: "block",
										minWidth: 0
									},
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("select", {
										"aria-label": "角色主题",
										value: room?.activeTheme || "modern",
										onChange: (e) => void updateRoom("theme", { theme: e.target.value }),
										style: {
											width: "100%",
											height: 30,
											boxSizing: "border-box",
											appearance: "none",
											WebkitAppearance: "none",
											border: "1px solid var(--dsw-alias-border-l2, rgba(255,255,255,0.14))",
											borderRadius: 10,
											background: "var(--dsw-alias-bg-layer-2, #202025)",
											color: "var(--dsw-alias-label-primary, #f8fafc)",
											font: "inherit",
											fontSize: 12,
											padding: "0 28px 0 10px",
											outline: "none"
										},
										children: [
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
												value: "meme_comedy",
												children: "沙雕整活"
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
												value: "genshin",
												children: "原神提瓦特"
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
												value: "modern",
												children: "现代精英"
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
												value: "three_kingdoms",
												children: "三国风云"
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
												value: "legends",
												children: "现代传奇"
											})
										]
									}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("svg", {
										viewBox: "0 0 16 16",
										fill: "none",
										stroke: "currentColor",
										strokeWidth: "1.8",
										strokeLinecap: "round",
										strokeLinejoin: "round",
										"aria-hidden": "true",
										style: {
											position: "absolute",
											right: 9,
											top: "50%",
											width: 14,
											height: 14,
											transform: "translateY(-50%)",
											pointerEvents: "none",
											color: "var(--dsw-alias-label-tertiary,#9ca3af)"
										},
										children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M4 6l4 4 4-4" })
									})]
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									style: {
										color: "var(--dsw-alias-label-secondary, #cbd5e1)",
										height: 30,
										display: "inline-flex",
										alignItems: "center"
									},
									children: "调度模式"
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
									style: {
										position: "relative",
										display: "block",
										minWidth: 0
									},
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("select", {
										"aria-label": "调度模式",
										value: room?.dispatchMode || "mention_only",
										onChange: (e) => void updateRoom("mode", { mode: e.target.value }),
										style: {
											width: "100%",
											height: 30,
											boxSizing: "border-box",
											appearance: "none",
											WebkitAppearance: "none",
											border: "1px solid var(--dsw-alias-border-l2, rgba(255,255,255,0.14))",
											borderRadius: 10,
											background: "var(--dsw-alias-bg-layer-2, #202025)",
											color: "var(--dsw-alias-label-primary, #f8fafc)",
											font: "inherit",
											fontSize: 12,
											padding: "0 28px 0 10px",
											outline: "none"
										},
										children: [
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
												value: "mention_only",
												children: "仅 @ 角色"
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
												value: "workflow_driven",
												children: "工作流"
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
												value: "moderator_led",
												children: "主持人调度"
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
												value: "free_discussion",
												children: "自由讨论"
											})
										]
									}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("svg", {
										viewBox: "0 0 16 16",
										fill: "none",
										stroke: "currentColor",
										strokeWidth: "1.8",
										strokeLinecap: "round",
										strokeLinejoin: "round",
										"aria-hidden": "true",
										style: {
											position: "absolute",
											right: 9,
											top: "50%",
											width: 14,
											height: 14,
											transform: "translateY(-50%)",
											pointerEvents: "none",
											color: "var(--dsw-alias-label-tertiary,#9ca3af)"
										},
										children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M4 6l4 4 4-4" })
									})]
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "查看调度模式 QA 说明",
									title: "调度模式 QA",
									onClick: () => setModeHelpOpen(true),
									style: {
										width: 28,
										height: 28,
										borderRadius: 9,
										border: "1px solid var(--dsw-alias-border-l2, rgba(255,255,255,0.14))",
										background: "var(--dsw-alias-bg-layer-2,#202025)",
										color: "var(--dsw-alias-label-secondary,#cbd5e1)",
										fontSize: 13,
										fontWeight: 700,
										cursor: "pointer"
									},
									children: "?"
								}),
								managementError && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									role: "alert",
									style: {
										gridColumn: "1 / -1",
										color: "#fca5a5"
									},
									children: managementError
								})
							]
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							style: {
								display: "flex",
								padding: "6px 12px",
								gap: "6px",
								background: "var(--dsw-alias-bg-layer-2, #1b1b1f)",
								borderBottom: "1px solid var(--dsw-alias-border-l2, rgba(255,255,255,0.06))"
							},
							children: [
								{
									id: "workflow",
									label: "工作流拓扑"
								},
								{
									id: "scratchpad",
									label: "共享黑板"
								},
								{
									id: "roster",
									label: "角色与账本"
								}
							].map((tab) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								onClick: () => setActiveTab(tab.id),
								style: {
									flex: 1,
									padding: "4px 6px",
									fontSize: "11px",
									borderRadius: "6px",
									border: "none",
									cursor: "pointer",
									background: activeTab === tab.id ? "var(--dsw-alias-bg-layer-3, #2a2a30)" : "transparent",
									color: activeTab === tab.id ? "var(--dsw-alias-label-primary, #fff)" : "var(--dsw-alias-label-tertiary, #94a3b8)",
									fontWeight: activeTab === tab.id ? 600 : 400
								},
								children: tab.label
							}, tab.id))
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							style: {
								flex: 1,
								overflowY: "auto",
								padding: "12px",
								fontSize: "12px"
							},
							children: [
								activeTab === "workflow" && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									style: {
										display: "flex",
										flexDirection: "column",
										gap: "10px"
									},
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
										style: {
											fontSize: "11px",
											fontWeight: 600,
											color: "var(--dsw-alias-label-secondary, #94a3b8)",
											marginBottom: "4px",
											display: "flex",
											justifyContent: "space-between"
										},
										children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", { children: [
											"阶段流程（共 ",
											room?.workflow?.stages?.length || 0,
											" 步）"
										] }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											style: { color: "var(--dsw-alias-state-business-primary, #4d6bfe)" },
											children: room?.workflow?.isCompleted ? "已全部验收完成 ✓" : `进行中: 第 ${(room?.workflow?.currentStageIndex || 0) + 1} 步`
										})]
									}), room?.workflow?.stages.map((st, idx) => {
										const isCurrent = idx === room.workflow.currentStageIndex && !room.workflow.isCompleted;
										const isPast = idx < room.workflow.currentStageIndex || room.workflow.isCompleted;
										const isWaitingApproval = st.status === "awaiting_approval";
										return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
											style: {
												padding: "8px 10px",
												borderRadius: "8px",
												background: isCurrent ? "rgba(77, 107, 254, 0.08)" : "var(--dsw-alias-bg-layer-2, #1b1b1f)",
												border: isCurrent ? "1px solid var(--dsw-alias-state-business-primary, #4d6bfe)" : "1px solid var(--dsw-alias-border-l1, rgba(255,255,255,0.06))"
											},
											children: [
												/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
													style: {
														display: "flex",
														alignItems: "center",
														justifyContent: "space-between"
													},
													children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
														style: {
															display: "flex",
															alignItems: "center",
															gap: "6px"
														},
														children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															style: {
																width: "18px",
																height: "18px",
																borderRadius: "50%",
																display: "inline-flex",
																alignItems: "center",
																justifyContent: "center",
																fontSize: "10px",
																fontWeight: 700,
																backgroundColor: isPast ? "#10b981" : isCurrent ? "#4d6bfe" : "#475569",
																color: "#fff"
															},
															children: isPast ? "✓" : idx + 1
														}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															style: {
																fontWeight: 600,
																color: "var(--dsw-alias-label-primary, #f8fafc)"
															},
															children: st.name
														})]
													}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
														style: {
															fontSize: "10px",
															padding: "1px 6px",
															borderRadius: "10px",
															backgroundColor: isWaitingApproval ? "rgba(234, 179, 8, 0.15)" : isCurrent ? "rgba(77, 107, 254, 0.15)" : "transparent",
															color: isWaitingApproval ? "#eab308" : isCurrent ? "#60a5fa" : "var(--dsw-alias-label-caption, #64748b)"
														},
														children: st.status
													})]
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
													style: {
														fontSize: "11px",
														color: "var(--dsw-alias-label-tertiary, #94a3b8)",
														marginTop: "4px"
													},
													children: st.description
												}),
												isWaitingApproval && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
													style: {
														marginTop: "8px",
														padding: "6px 8px",
														borderRadius: "6px",
														background: "rgba(234, 179, 8, 0.1)",
														border: "1px dashed rgba(234, 179, 8, 0.3)",
														display: "flex",
														alignItems: "center",
														justifyContent: "space-between"
													},
													children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
														style: {
															color: "#eab308",
															fontSize: "11px"
														},
														children: "⚠️ 产物就绪，等待指挥官放行"
													}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
														onClick: handleApproveStage,
														style: {
															backgroundColor: "#10b981",
															color: "#fff",
															border: "none",
															borderRadius: "4px",
															padding: "2px 8px",
															fontSize: "10px",
															cursor: "pointer",
															fontWeight: 600
														},
														children: "批准放行"
													})]
												})
											]
										}, st.id);
									})]
								}),
								activeTab === "scratchpad" && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									style: {
										display: "flex",
										flexDirection: "column",
										height: "100%",
										gap: "8px"
									},
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
										style: {
											display: "flex",
											justifyContent: "space-between",
											alignItems: "center"
										},
										children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											style: {
												color: "var(--dsw-alias-label-secondary, #94a3b8)",
												fontSize: "11px"
											},
											children: "团队共识备忘录 (Markdown)"
										}), !isEditingScratchpad ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
											onClick: () => setIsEditingScratchpad(true),
											style: {
												background: "transparent",
												border: "1px solid var(--dsw-alias-border-l2, rgba(255,255,255,0.1))",
												color: "var(--dsw-alias-label-primary, #fff)",
												fontSize: "10px",
												borderRadius: "4px",
												padding: "2px 6px",
												cursor: "pointer"
											},
											children: "✏️ 编辑"
										}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
											onClick: handleSaveScratchpad,
											style: {
												backgroundColor: "var(--dsw-alias-state-business-primary, #4d6bfe)",
												color: "#fff",
												border: "none",
												fontSize: "10px",
												borderRadius: "4px",
												padding: "2px 8px",
												cursor: "pointer",
												fontWeight: 600
											},
											children: "保存"
										})]
									}), isEditingScratchpad ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("textarea", {
										value: scratchpadDraft,
										onChange: (e) => setScratchpadDraft(e.target.value),
										style: {
											flex: 1,
											minHeight: "260px",
											width: "100%",
											background: "var(--dsw-alias-bg-layer-2, #1b1b1f)",
											border: "1px solid var(--dsw-alias-border-l2, rgba(255,255,255,0.1))",
											borderRadius: "8px",
											color: "var(--dsw-alias-label-primary, #f8fafc)",
											fontFamily: "monospace",
											fontSize: "11px",
											padding: "8px",
											resize: "none"
										}
									}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
										style: {
											flex: 1,
											minHeight: "260px",
											background: "var(--dsw-alias-bg-layer-2, #1b1b1f)",
											border: "1px solid var(--dsw-alias-border-l1, rgba(255,255,255,0.06))",
											borderRadius: "8px",
											padding: "10px",
											color: "var(--dsw-alias-label-primary, #f8fafc)",
											whiteSpace: "pre-wrap",
											overflowY: "auto",
											lineHeight: "1.5"
										},
										children: scratchpadDraft || "（暂无黑板内容，指挥官与文案写手可随时写入技术决策）"
									})]
								}),
								activeTab === "roster" && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									style: {
										display: "flex",
										flexDirection: "column",
										gap: "8px"
									},
									children: [
										/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
											style: {
												background: "linear-gradient(135deg, rgba(236,72,153,0.12), rgba(77,107,254,0.10))",
												padding: "10px 12px",
												borderRadius: "10px",
												border: "1px solid rgba(236,72,153,0.22)",
												display: "grid",
												gap: "8px"
											},
											children: [
												/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
													style: {
														display: "flex",
														justifyContent: "space-between",
														alignItems: "center",
														gap: 8
													},
													children: [
														/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
															style: {
																fontSize: 12,
																fontWeight: 700,
																color: "var(--dsw-alias-label-primary,#f8fafc)"
															},
															children: "AI 造主题角色 + 工作流"
														}),
														/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => void updateRoom("theme", { theme: "meme_comedy" }),
															style: {
																fontSize: 10,
																padding: "3px 8px",
																borderRadius: 999,
																border: "1px solid rgba(255,255,255,0.14)",
																background: "var(--dsw-alias-bg-layer-2,#202025)",
																color: "var(--dsw-alias-label-primary,#fff)",
																cursor: "pointer"
															},
															children: "套用沙雕整活"
														}),
														/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => void updateRoom("theme", { theme: "genshin" }),
															style: {
																fontSize: 10,
																padding: "3px 8px",
																borderRadius: 999,
																border: "1px solid rgba(255,255,255,0.14)",
																background: "var(--dsw-alias-bg-layer-2,#202025)",
																color: "var(--dsw-alias-label-primary,#fff)",
																cursor: "pointer"
															},
															children: "套用原神"
														})
													]
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)("textarea", {
													value: themeBrief,
													onChange: (e) => setThemeBrief(e.target.value),
													placeholder: "例如：赛博修仙创业公司做知识库、猫猫宇宙产品战队改插件、东北烧烤摊式研发部做运营页……",
													style: {
														minHeight: 54,
														resize: "vertical",
														borderRadius: 9,
														border: "1px solid var(--dsw-alias-border-l2, rgba(255,255,255,0.12))",
														background: "var(--dsw-alias-bg-layer-1,#151518)",
														color: "var(--dsw-alias-label-primary,#f8fafc)",
														fontSize: 11,
														lineHeight: 1.45,
														padding: "8px"
													}
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
													style: {
														display: "flex",
														gap: 8
													},
													children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
														type: "button",
														disabled: themeBusy,
														onClick: () => void generateThemeDraft(false),
														style: {
															flex: 1,
															fontSize: 11,
															padding: "6px 8px",
															borderRadius: 9,
															border: "1px solid rgba(255,255,255,0.14)",
															background: "var(--dsw-alias-bg-layer-2,#202025)",
															color: "var(--dsw-alias-label-primary,#fff)",
															cursor: "pointer"
														},
														children: themeBusy ? "生成中…" : "生成草案"
													}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
														type: "button",
														disabled: themeBusy,
														onClick: () => void generateThemeDraft(true),
														style: {
															flex: 1,
															fontSize: 11,
															padding: "6px 8px",
															borderRadius: 9,
															border: "none",
															background: "var(--dsw-alias-state-business-primary,#4d6bfe)",
															color: "#fff",
															cursor: "pointer",
															fontWeight: 700
														},
														children: "生成并套用"
													})]
												}),
												themeDraft.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
													style: {
														display: "grid",
														gap: 6
													},
													children: [
														/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
															style: {
																fontSize: 10,
																color: "var(--dsw-alias-label-tertiary,#94a3b8)"
															},
															children: "草案预览：会同时生成工作流；可先套用，再用每个角色右侧「编辑」细调。"
														}),
														workflowDraft && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
															style: {
																fontSize: 10,
																color: "var(--dsw-alias-label-secondary,#cbd5e1)",
																padding: "6px 7px",
																borderRadius: 8,
																background: "rgba(77,107,254,0.10)"
															},
															children: [
																"工作流：",
																workflowDraft.title,
																" · ",
																workflowDraft.stages?.length || 0,
																" 步"
															]
														}),
														themeDraft.map((item) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
															style: {
																display: "flex",
																alignItems: "center",
																gap: 7,
																fontSize: 11,
																color: "var(--dsw-alias-label-secondary,#cbd5e1)",
																minWidth: 0
															},
															children: [
																/* @__PURE__ */ (0, react_jsx_runtime.jsx)(AvatarBadge, {
																	avatar: item.avatar,
																	className: "gc-roster-avatar"
																}),
																/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
																	style: {
																		fontWeight: 700,
																		color: "var(--dsw-alias-label-primary,#fff)"
																	},
																	children: item.name
																}),
																/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
																	style: {
																		overflow: "hidden",
																		textOverflow: "ellipsis",
																		whiteSpace: "nowrap"
																	},
																	children: item.title
																})
															]
														}, item.id)),
														/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
															type: "button",
															disabled: themeBusy,
															onClick: () => void generateThemeDraft(true),
															style: {
																fontSize: 11,
																padding: "6px 8px",
																borderRadius: 9,
																border: "none",
																background: "#10b981",
																color: "#fff",
																cursor: "pointer",
																fontWeight: 700
															},
															children: "套用这个草案"
														})
													]
												})
											]
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
											style: {
												background: "var(--dsw-alias-bg-layer-2, #1b1b1f)",
												padding: "10px 12px",
												borderRadius: "10px",
												border: "1px solid var(--dsw-alias-border-l1, rgba(255,255,255,0.06))",
												display: "grid",
												gap: "8px"
											},
											children: [
												/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
													style: {
														display: "flex",
														alignItems: "center",
														justifyContent: "space-between",
														gap: 8
													},
													children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
														style: {
															fontSize: "11px",
															color: "var(--dsw-alias-label-secondary, #94a3b8)",
															fontWeight: 600
														},
														children: "总体运行统计"
													}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
														style: {
															fontSize: "10px",
															color: "var(--dsw-alias-label-caption, #64748b)"
														},
														children: "官方摘要风格"
													})]
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
													style: {
														fontSize: "11px",
														lineHeight: 1.55,
														color: "var(--dsw-alias-label-primary,#f8fafc)",
														whiteSpace: "normal"
													},
													children: metricLine(ledger?.totalCalls || 0, ledger?.metrics || mergeMetrics(Object.values(ledger?.agentStats || {}).map((s) => s.metrics)))
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("details", {
													style: {
														borderTop: "1px solid var(--dsw-alias-border-l1, rgba(255,255,255,0.06))",
														paddingTop: 8
													},
													children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("summary", {
														style: {
															cursor: "pointer",
															fontSize: 11,
															color: "var(--dsw-alias-label-secondary,#cbd5e1)",
															userSelect: "none"
														},
														children: "按 Agent / 模型展开"
													}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
														style: {
															display: "grid",
															gap: 8,
															marginTop: 8
														},
														children: [Object.entries(ledger?.agentStats || {}).map(([agentId, stat]) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
															style: {
																padding: "8px 9px",
																borderRadius: 8,
																background: "var(--dsw-alias-bg-layer-1,#151518)",
																border: "1px solid var(--dsw-alias-border-l1, rgba(255,255,255,0.06))"
															},
															children: [
																/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
																	style: {
																		display: "flex",
																		justifyContent: "space-between",
																		gap: 8,
																		fontSize: 11,
																		fontWeight: 700,
																		color: "var(--dsw-alias-label-primary,#f8fafc)"
																	},
																	children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: stat.agentName }), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", { children: [stat.totalTokens || 0, " T"] })]
																}),
																/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
																	style: {
																		fontSize: 10,
																		color: "var(--dsw-alias-label-tertiary,#94a3b8)",
																		marginTop: 4
																	},
																	children: metricLine(stat.callCount || 0, stat.metrics)
																}),
																Object.values(stat.modelStats || {}).map((ms) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
																	style: {
																		marginTop: 6,
																		paddingTop: 6,
																		borderTop: "1px dashed var(--dsw-alias-border-l1, rgba(255,255,255,0.08))",
																		fontSize: 10,
																		color: "var(--dsw-alias-label-secondary,#cbd5e1)"
																	},
																	children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
																		style: {
																			fontWeight: 600,
																			color: "var(--dsw-alias-label-primary,#f8fafc)",
																			overflow: "hidden",
																			textOverflow: "ellipsis",
																			whiteSpace: "nowrap"
																		},
																		children: [
																			ms.provider,
																			" / ",
																			ms.model
																		]
																	}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
																		style: {
																			marginTop: 2,
																			color: "var(--dsw-alias-label-tertiary,#94a3b8)"
																		},
																		children: metricLine(ms.callCount || 0, ms.metrics)
																	})]
																}, `${ms.provider}/${ms.model}`))
															]
														}, agentId)), Object.keys(ledger?.agentStats || {}).length === 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
															style: {
																fontSize: 11,
																color: "var(--dsw-alias-label-tertiary,#94a3b8)"
															},
															children: "暂无 Agent 调用记录；首次角色发言后会显示分项。"
														})]
													})]
												})
											]
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
											style: {
												fontSize: "11px",
												color: "var(--dsw-alias-label-secondary, #94a3b8)",
												marginTop: "4px"
											},
											children: [
												"成员列表（",
												room?.members.length || 0,
												" 人）"
											]
										}),
										room?.members.map((member) => {
											const stat = ledger?.agentStats[member.id];
											return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
												style: {
													display: "flex",
													alignItems: "center",
													justifyContent: "space-between",
													padding: "6px 8px",
													borderRadius: "6px",
													background: "var(--dsw-alias-bg-layer-2, #1b1b1f)"
												},
												children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
													style: {
														display: "flex",
														alignItems: "center",
														gap: "8px"
													},
													children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(AvatarBadge, {
														avatar: member.avatar,
														className: "gc-roster-avatar"
													}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
														style: {
															fontWeight: 600,
															color: "var(--dsw-alias-label-primary, #f8fafc)",
															fontSize: "11px"
														},
														children: member.name
													}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
														style: {
															fontSize: "10px",
															color: "var(--dsw-alias-label-caption, #64748b)"
														},
														children: member.title || member.id
													})] })]
												}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
													style: {
														textAlign: "right",
														fontSize: "10px",
														color: "var(--dsw-alias-label-tertiary, #94a3b8)",
														display: "flex",
														alignItems: "center",
														gap: "6px",
														whiteSpace: "nowrap"
													},
													children: [
														/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", { children: [stat?.callCount || 0, " 轮"] }),
														/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", { children: [stat?.totalTokens || 0, " T"] }),
														/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => setEditingAgent(member),
															"aria-label": `编辑${member.name}`,
															children: "编辑"
														})
													]
												})]
											}, member.id);
										})
									]
								})
							]
						})
					]
				})
			] });
		}
		//#endregion
		//#region src/client/index.ts
		/**
		* @dsh-external/dsh-group-chat — Client 前端入口
		*
		* 挂载模式：
		* 1. conversation.view: 主视区全屏工作台 Tab（多 Agent 沉浸式状态机推演主战场 + 角色编辑与头像上传）
		* 2. shell.overlay: 右侧伴随监控副屏（Companion HUD：工作流拓扑 + 共享黑板 + 成员账本，不重叠主对话区）
		* 3. conversation.composer: 不注册官方 chain slot；由 layout-push.ts 的 CSS 在特遣协同激活时隐藏原生输入框
		*/
		const inject = ["slots"];
		function apply(ctx) {
			ctx.effect(() => () => disposeGroupChatEvents(), "dsh-group-chat: events");
			ctx.effect(() => injectLayoutPushStyles(), "dsh-group-chat: styles");
			ctx.effect(() => {
				return ctx.slots.inject("conversation.view", () => {
					return ctx.slots.register({
						name: "conversation.view",
						id: "dsh-group-chat",
						order: 20,
						label: () => "特遣协同",
						component: () => (0, react.createElement)(GroupChatPanel, { mode: "full" })
					}, GroupChatPanel);
				});
			}, "dsh-group-chat: conversation.view panel");
			ctx.effect(() => {
				return ctx.slots.inject("shell.overlay", () => {
					return ctx.slots.register({
						name: "shell.overlay",
						id: "dsh-group-chat-dock",
						order: 50
					}, GroupChatSideDock);
				});
			}, "dsh-group-chat: layout-push side dock");
		}
		//#endregion
		exports.apply = apply;
		exports.inject = inject;
		return module.exports;
	}
});

//# sourceMappingURL=client.js.map