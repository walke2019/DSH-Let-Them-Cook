import type { ModelRef, ResiliencePolicy } from '../types.js';
export interface RoleModels {
    llmConfig: ModelRef;
    resiliencePolicy?: ResiliencePolicy;
}
export declare function validateModels(primary: ModelRef, policy?: ResiliencePolicy): void;
/** Plugin-owned settings only. No host credential or core configuration is written. */
export declare class ModelSettingsStore {
    private path;
    private data;
    constructor(path: string);
    get(room: string, role: string): RoleModels;
    recent(): ModelRef[];
    forget(model: ModelRef): void;
    remember(model: ModelRef): void;
    save(room: string, role: string, value: RoleModels): void;
}
